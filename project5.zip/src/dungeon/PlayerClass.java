
package dungeon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class that represents a player in the dungeon world. PLayer is placed in a cave which is decided
 * as the start in the dungeon. Player can move in the possible direction from a given location to
 * reach the end point. While moving through the dungeon player can collect treasure.
 */
public class PlayerClass implements dungeon.Player {
  private final int playerId;
  private final String playerName;
  private Map<Treasure, Integer> treasureCollected;
  private List<Sides> sidesList;
  private int currenLoc;
  private int arrowCurrenLoc;
  private final dungeon.Cell[][] dungCell;
  private final int[][] dung;
  private List<Treasure> treasureInCell;
  private final Map<Integer, List<Integer>> matrixLoc;
  private final List<ArrayList<Integer>> adjtemp;
  private final int wrapping;
  private int arrowList;

  /**
   * Constructor to initialise the player class and pass in details about the dungeon to the
   * player.
   *
   * @param playerID   Player id
   * @param playerName player name
   * @param start      start cell in dungeon
   * @param dung       matrix that has value at each row and col for dungeon
   * @param cellDung   Matrix to store cell object in the dungeon
   * @param matrixLoc  Hashmap that gets coordinated given the point in matrix
   * @param adjtemp    adjacency list containing the connections between nodes in the dungeon
   */
  public PlayerClass(int playerID, String playerName, int start, int[][] dung,
                     dungeon.Cell[][] cellDung, Map<Integer, List<Integer>> matrixLoc,
                     List<ArrayList<Integer>> adjtemp, int wrapping) {
    if (playerID < 0) {
      throw new IllegalArgumentException("Invalid id");
    }
    if (playerName == null) {
      throw new IllegalArgumentException("Invalid name");
    }
    if (start < 0) {
      throw new IllegalArgumentException("Please enter a valid start location");
    }
    if (dung == null) {
      throw new IllegalArgumentException("Please enter a valid dung");
    }
    if (cellDung == null) {
      throw new IllegalArgumentException("Please enter a valid dungcell object");
    }
    if (matrixLoc == null) {
      throw new IllegalArgumentException("Please enter a valid matrix hashmap");
    }
    if (adjtemp == null) {
      throw new IllegalArgumentException("Invalid adjacency list");
    }
    if (!(wrapping == 1 || wrapping == 2)) {
      throw new IllegalArgumentException("Please enter a valid value");
    }
    this.wrapping = wrapping;
    this.treasureCollected = new HashMap<>();
    this.playerId = playerID;
    this.playerName = playerName;
    this.currenLoc = start;
    this.dung = dung;
    this.treasureInCell = new ArrayList<>();
    this.adjtemp = adjtemp;
    this.dungCell = cellDung;
    this.sidesList = new ArrayList<>();
    treasureCollected.put(Treasure.DIAMONDS, 0);
    treasureCollected.put(Treasure.RUBIES, 0);
    treasureCollected.put(Treasure.SAPPHIRES, 0);
    this.matrixLoc = matrixLoc;
    this.arrowList = 3;
    this.arrowCurrenLoc = currenLoc;
    determineCellVisited();
  }

  @Override
  public int getPlayerID() {
    int copyPlayerId;
    copyPlayerId = playerId;
    return copyPlayerId;
  }

  @Override
  public String getName() {
    String copyPlayerName;
    copyPlayerName = playerName;
    return copyPlayerName;
  }

  @Override
  public StringBuilder getDescription() {
    StringBuilder str = new StringBuilder();
    str.append("Player id: " + getPlayerID());
    str.append("\n");
    str.append("Player Name: " + getName());
    str.append("\n");
    str.append("TreasureCollected till now : " + getTreasureCollected());
    str.append("\n");
    str.append("Arrows collected : " + getPlayerArrowCount());
    str.append("\n");
    return str;
  }

  @Override
  public Map<Treasure, Integer> getTreasureCollected() {
    Map<Treasure, Integer> copyTreasureCollected = new HashMap<>();
    for (Map.Entry<Treasure, Integer> entry : treasureCollected.entrySet()) {
      copyTreasureCollected.put(entry.getKey(), entry.getValue());
    }
    return copyTreasureCollected;
  }

  @Override
  public int getCurrentLocation() {
    int copyCurrentLoc;
    copyCurrentLoc = currenLoc;
    return copyCurrentLoc;
  }

  @Override
  public void addTreasureCollected() {
    List<Integer> currLoc = new ArrayList<>();

    currLoc = matrixLoc.get(currenLoc);
    int row = currLoc.get(0);
    int col = currLoc.get(1);

    if (dungCell[row][col].getCellType().equals("Cave")) {
      treasureInCell = dungCell[row][col].getTreasure();
    }
    for (Treasure t : treasureInCell) {
      Integer count = treasureCollected.getOrDefault(t, 0);
      treasureCollected.put(t, count + 1);

      if (dungCell[row][col].getCellType().equals("Cave")) {
        dungCell[row][col].updateTreasure();
      }
    }
  }

  @Override
  public void movePlayer(Sides side) {
    if (side == null) {
      throw new IllegalArgumentException("Invalid Side");
    }
    setPossibleMoves();

    for (Sides s : sidesList) {
      if (side == s) {

        List<Integer> currLoc = new ArrayList<>();
        currLoc = matrixLoc.get(currenLoc);

        int row = currLoc.get(0);
        int col = currLoc.get(1);
        if (wrapping == 2) {
          if (side == Sides.NORTH) {
            currenLoc = dung[row - 1][col];
          } else if (side == Sides.EAST) {
            currenLoc = dung[row][col + 1];
          } else if (side == Sides.WEST) {
            currenLoc = dung[row][col - 1];
          } else if (side == Sides.SOUTH) {
            currenLoc = dung[row + 1][col];
          }
        } else if (wrapping == 1) {
          if (side == Sides.NORTH && (row - 1 >= 0)) {
            currenLoc = dung[row - 1][col];
          } else if (side == Sides.NORTH && (row - 1 < 0)) {
            currenLoc = dung[(dung.length) - 1][col];
          } else if (side == Sides.EAST && (col + 1 < dung[0].length)) {
            currenLoc = dung[row][col + 1];
          } else if (side == Sides.EAST && (col + 1 >= dung[0].length)) {
            currenLoc = dung[row][0];
          } else if (side == Sides.WEST && (col - 1 >= 0)) {
            currenLoc = dung[row][col - 1];
          } else if (side == Sides.WEST && (col - 1 < 0)) {
            currenLoc = dung[row][(dung[0].length) - 1];
          } else if (side == Sides.SOUTH && (row + 1 < dung.length)) {
            currenLoc = dung[row + 1][col];
          } else if (side == Sides.SOUTH && (row + 1 >= dung.length)) {
            currenLoc = dung[0][col];
          }
        }
      }
    }
    determineCellVisited();
  }

  @Override
  public void setPossibleMoves() {
    List<Integer> currLoc = new ArrayList<>();

    currLoc = matrixLoc.get(currenLoc);
    int row = currLoc.get(0);
    int col = currLoc.get(1);

    dungCell[row][col].findConnectedCells(dungCell[0].length, dungCell.length,
            dung, adjtemp, wrapping);
    sidesList = new ArrayList<>();

    for (Sides s : dungCell[row][col].getConnectedSides()) {
      sidesList.add(s);
    }


  }

  @Override
  public void setPossibleArrowMoves() {
    List<Integer> currLoc = new ArrayList<>();

    currLoc = matrixLoc.get(arrowCurrenLoc);
    int row = currLoc.get(0);
    int col = currLoc.get(1);

    dungCell[row][col].findConnectedCells(dungCell[0].length, dungCell.length,
            dung, adjtemp, wrapping);
    sidesList = new ArrayList<>();

    for (Sides s : dungCell[row][col].getConnectedSides()) {
      sidesList.add(s);
    }


  }

  @Override
  public StringBuilder getPLayerLocationDesc() {
    treasureInCell = new ArrayList<>();
    List<Integer> currLoc = new ArrayList<>();

    currLoc = matrixLoc.get(currenLoc);
    int row = currLoc.get(0);
    int col = currLoc.get(1);

    if (dungCell[row][col].getCellType().equals("Cave")) {
      treasureInCell = dungCell[row][col].getTreasure();
    }


    StringBuilder str = new StringBuilder();
    str.append("Player currentLocation: " + dung[row][col]);
    str.append("\n");
    str.append("Treasure in the Room " + treasureInCell);
    str.append("\n");
    str.append("Does the room have an arrow? " + dungCell[row][col].getIsArrowed());
    str.append("\n");
    str.append("Possible moves from current locatino: " + getSidesList());
    str.append("\n");
    return str;
  }

  @Override
  public List<Sides> getSidesList() {
    List<Sides> copySideList = new ArrayList<>();
    for (Sides s : sidesList) {
      copySideList.add(s);
    }

    return copySideList;
  }

  @Override
  public List<Treasure> getTreasureInCell() {
    List<Treasure> copyTreasure = new ArrayList<>();
    for (Treasure t : treasureInCell) {
      copyTreasure.add(t);
    }

    return copyTreasure;

  }

  @Override
  public void addArrowList() {
    //getplayer locaton
    List<Integer> currLoc = new ArrayList<>();

    currLoc = matrixLoc.get(currenLoc);
    int row = currLoc.get(0);
    int col = currLoc.get(1);
    // check if arrow is there in loc
    Boolean arrowInCell = dungCell[row][col].getIsArrowed();

    // if its there then add increase arrow count for player
    if (arrowInCell) {
      arrowList++;
    }
    dungCell[row][col].setIsArrowed(false);
    // call function set arrow count as false in cell.
  }

  @Override
  public int getPlayerArrowCount() {
    int copyArrowList;
    copyArrowList = arrowList;
    return copyArrowList;
  }

  @Override
  public String slayOtyugh(Sides initialDirection, int distance) {
    if (initialDirection == null) {
      throw new IllegalArgumentException("Invalid Side");
    }
    arrowList--;
    StringBuffer buf = new StringBuffer();
    List<Integer> arrowCurrLoc = new ArrayList<>();
    Boolean flag = true;
    arrowCurrenLoc = currenLoc;
    arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
    Sides arrowDirection = initialDirection;

    int row = arrowCurrLoc.get(0);
    int col = arrowCurrLoc.get(1);


    while ((distance > 0 && dungCell[row][col].getCellType().equals("Cave")) && flag
            || dungCell[row][col].getCellType().equals("Tunnel") && flag) {
      arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
      row = arrowCurrLoc.get(0);
      col = arrowCurrLoc.get(1);
      if (dungCell[row][col].getCellType().equals("Cave")) {
        if (arrowDirection == null) {
          throw new IllegalArgumentException("Invalid Side");
        }
        setPossibleArrowMoves();
        arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);


        row = arrowCurrLoc.get(0);
        col = arrowCurrLoc.get(1);
        if (sidesList.contains(arrowDirection)) {
          distance--;
          if (wrapping == 2) {
            if (arrowDirection == Sides.NORTH) {
              arrowCurrenLoc = dung[row - 1][col];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            } else if (arrowDirection == Sides.EAST) {
              arrowCurrenLoc = dung[row][col + 1];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            } else if (arrowDirection == Sides.WEST) {
              arrowCurrenLoc = dung[row][col - 1];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            } else if (arrowDirection == Sides.SOUTH) {
              arrowCurrenLoc = dung[row + 1][col];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            }
          } else if (wrapping == 1) {
            if (arrowDirection == Sides.NORTH && (row - 1 >= 0)) {
              arrowCurrenLoc = dung[row - 1][col];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            } else if (arrowDirection == Sides.NORTH && (row - 1 < 0)) {
              arrowCurrenLoc = dung[(dung.length) - 1][col];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            } else if (arrowDirection == Sides.EAST && (col + 1 < dung[0].length)) {
              arrowCurrenLoc = dung[row][col + 1];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            } else if (arrowDirection == Sides.EAST && (col + 1 >= dung[0].length)) {
              arrowCurrenLoc = dung[row][0];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            } else if (arrowDirection == Sides.WEST && (col - 1 >= 0)) {
              arrowCurrenLoc = dung[row][col - 1];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            } else if (arrowDirection == Sides.WEST && (col - 1 < 0)) {
              arrowCurrenLoc = dung[row][(dung[0].length) - 1];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            } else if (arrowDirection == Sides.SOUTH && (row + 1 < dung.length)) {
              arrowCurrenLoc = dung[row + 1][col];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            } else if (arrowDirection == Sides.SOUTH && (row + 1 >= dung.length)) {
              arrowCurrenLoc = dung[0][col];
              arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
              row = arrowCurrLoc.get(0);
              col = arrowCurrLoc.get(1);
            }
          }

        } else {
          flag = false;
        }


      } else if (dungCell[row][col].getCellType().equals("Tunnel")) {
        if (arrowDirection == null) {
          throw new IllegalArgumentException("Invalid Side");
        }
        if (arrowCurrenLoc == currenLoc) {
          distance--;
        }
        setPossibleArrowMoves();
        if (wrapping == 2) {
          if (arrowDirection == Sides.NORTH) {
            arrowCurrenLoc = dung[row - 1][col];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          } else if (arrowDirection == Sides.EAST) {
            arrowCurrenLoc = dung[row][col + 1];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          } else if (arrowDirection == Sides.WEST) {
            arrowCurrenLoc = dung[row][col - 1];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          } else if (arrowDirection == Sides.SOUTH) {
            arrowCurrenLoc = dung[row + 1][col];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          }
        } else if (wrapping == 1) {
          if (arrowDirection == Sides.NORTH && (row - 1 >= 0)) {
            arrowCurrenLoc = dung[row - 1][col];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          } else if (arrowDirection == Sides.NORTH && (row - 1 < 0)) {
            arrowCurrenLoc = dung[(dung.length) - 1][col];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          } else if (arrowDirection == Sides.EAST && (col + 1 < dung[0].length)) {
            arrowCurrenLoc = dung[row][col + 1];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          } else if (arrowDirection == Sides.EAST && (col + 1 >= dung[0].length)) {
            arrowCurrenLoc = dung[row][0];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          } else if (arrowDirection == Sides.WEST && (col - 1 >= 0)) {
            arrowCurrenLoc = dung[row][col - 1];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          } else if (arrowDirection == Sides.WEST && (col - 1 < 0)) {
            arrowCurrenLoc = dung[row][(dung[0].length) - 1];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          } else if (arrowDirection == Sides.SOUTH && (row + 1 < dung.length)) {
            arrowCurrenLoc = dung[row + 1][col];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          } else if (arrowDirection == Sides.SOUTH && (row + 1 >= dung.length)) {
            arrowCurrenLoc = dung[0][col];
            arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
            row = arrowCurrLoc.get(0);
            col = arrowCurrLoc.get(1);
          }
        }
        if (sidesList.get(0) == Sides.NORTH && sidesList.get(1) == Sides.SOUTH
                &&
                arrowDirection == Sides.NORTH) {
          arrowDirection = Sides.NORTH;
          arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
          row = arrowCurrLoc.get(0);
          col = arrowCurrLoc.get(1);
        } else if (sidesList.get(0) == Sides.SOUTH && sidesList.get(1) == Sides.NORTH
                &&
                arrowDirection == Sides.SOUTH) {
          arrowDirection = Sides.SOUTH;
          arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
          row = arrowCurrLoc.get(0);
          col = arrowCurrLoc.get(1);
        } else if (sidesList.get(0) == Sides.NORTH && sidesList.get(1) == Sides.SOUTH
                &&
                arrowDirection == Sides.SOUTH) {
          arrowDirection = Sides.SOUTH;
          arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
          row = arrowCurrLoc.get(0);
          col = arrowCurrLoc.get(1);
        } else if (sidesList.get(0) == Sides.SOUTH && sidesList.get(1) == Sides.NORTH
                &&
                arrowDirection == Sides.NORTH) {
          arrowDirection = Sides.NORTH;
          arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
          row = arrowCurrLoc.get(0);
          col = arrowCurrLoc.get(1);
        } else if (sidesList.get(0) == Sides.EAST && sidesList.get(1) == Sides.WEST
                &&
                arrowDirection == Sides.EAST) {
          arrowDirection = Sides.EAST;
          arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
          row = arrowCurrLoc.get(0);
          col = arrowCurrLoc.get(1);
        } else if (sidesList.get(0) == Sides.WEST && sidesList.get(1) == Sides.EAST
                &&
                arrowDirection == Sides.WEST) {
          arrowDirection = Sides.WEST;
          arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
          row = arrowCurrLoc.get(0);
          col = arrowCurrLoc.get(1);
        } else if (sidesList.get(0) == Sides.WEST && sidesList.get(1) == Sides.EAST
                &&
                arrowDirection == Sides.EAST) {
          arrowDirection = Sides.EAST;
          arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
          row = arrowCurrLoc.get(0);
          col = arrowCurrLoc.get(1);
        } else if (sidesList.get(0) == Sides.EAST && sidesList.get(1) == Sides.WEST
                &&
                arrowDirection == Sides.WEST) {
          arrowDirection = Sides.WEST;
          arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);
          row = arrowCurrLoc.get(0);
          col = arrowCurrLoc.get(1);
        } else {
          for (Sides s : sidesList) {
            if (arrowDirection != s) {
              arrowDirection = s;
            }
          }
        }
      }
    }
    arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);

    row = arrowCurrLoc.get(0);
    col = arrowCurrLoc.get(1);
    if (distance == 0) {
      buf.append("Arrow reached the desired cave !! Checking for otyughs").append("\n");

      if (dungCell[row][col].getOtyughsCount() == 0) {
        buf.append("Unfortunately no otyughs here !!").append("\n");
        return buf.toString();
      } else if (dungCell[row][col].getOtyughsCount() > 0) {
        dungCell[row][col].setHealth();
        buf.append("Otyughs here and health updated !!").append("\n");
        return buf.toString();
      }
    }

    buf.append("you shoot an arrow into darkness !!").append("\n");
    return buf.toString();

  }

  @Override
  public int getArrowCurrenLoc() {
    return arrowCurrenLoc;
  }

  @Override
  public String determineCellType() {
    List<Integer> currLoc = new ArrayList<>();

    currLoc = matrixLoc.get(currenLoc);
    int row = currLoc.get(0);
    int col = currLoc.get(1);
    if (dungCell[row][col].getCellType().equals("Cave")) {
      return "Cave";
    } else {
      return "Tunnel";
    }
  }

  @Override
  public String printExits() {
    StringBuffer buf = new StringBuffer();
    buf.append("Exits are at: (");
    for (Sides s : sidesList) {
      if (s == Sides.WEST) {
        // in west location
        buf.append("W ");
      }
      if (s == Sides.EAST) {
        // east location
        buf.append("E ");
      }
      if (s == Sides.SOUTH) {
        // south location
        buf.append("S ");
      }
      if (s == Sides.NORTH) {
        // north location
        buf.append("N ");
      }
    }

    buf.append(")" + "\n");
    return buf.toString();
  }

  @Override
  public String pick(String item) {
    if (item == null) {
      throw new IllegalArgumentException("Please enter a valid item");
    }
    StringBuffer buf = new StringBuffer();
    if (item.contains("Treasure")) {
      List<Integer> currLoc = new ArrayList<>();

      currLoc = matrixLoc.get(currenLoc);
      int row = currLoc.get(0);
      int col = currLoc.get(1);

      if (!dungCell[row][col].getTreasure().isEmpty()) {
        addTreasureCollected();
        buf.append("Picked Treasure !! \n");
        buf.append("collected treasure: " + getTreasureCollected());
      } else {
        buf.append("Nothing to pick from cave!!").append("\n");
      }
    } else if (item.contains("Arrow")) {
      // add a check to verify if arrow is present in the location
      List<Integer> currLoc = new ArrayList<>();

      currLoc = matrixLoc.get(currenLoc);
      int row = currLoc.get(0);
      int col = currLoc.get(1);
      // check if arrow is there in loc
      Boolean arrowInCell = dungCell[row][col].getIsArrowed();
      if (arrowInCell) {
        addArrowList();
        buf.append("Picked Arrow !! \n");
        buf.append("player has ").append(arrowList).append("arrows \n");
      } else {
        buf.append("Nothing to pick!!").append("\n");
      }
    } else {
      buf.append("Can pick only Treasure/Arrow").append("\n");
    }
    return buf.toString();
  }

  @Override
  public boolean checkOtyughExist() {
    List<Integer> arrowCurrLoc = new ArrayList<>();

    arrowCurrLoc = matrixLoc.get(arrowCurrenLoc);

    int row = arrowCurrLoc.get(0);
    int col = arrowCurrLoc.get(1);
    return (dungCell[row][col].getOtyughsCount() == 0);
  }

  @Override
  public void determineCellVisited() {
    List<Integer> currLoc = new ArrayList<>();
    currLoc = matrixLoc.get(currenLoc);
    int row = currLoc.get(0);
    int col = currLoc.get(1);
    dungCell[row][col].setVisitedFlag();
  }
}




