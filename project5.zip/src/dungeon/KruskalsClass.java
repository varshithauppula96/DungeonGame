package dungeon;


import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;


/**
 * Class to implement the kruskals algorithm to generate a grapgh structure which represents the
 * connectivity between the nodes which represent the caves and tunnels in the dungeon.
 */
public class KruskalsClass {
  private static List<Edge> mst;


  /**
   * Class to represent the edge between two given nodes.
   */
  public static class Edge {
    private int source;
    private int destination;

    /**
     * Constructor to initialise the parameters of the edge class.
     *
     * @param source      source
     * @param destination destination
     */
    public Edge(int source, int destination) {
      if (source < 0) {
        throw new IllegalArgumentException("Please enter a positive value");
      }
      if (destination < 0) {
        throw new IllegalArgumentException("Please enter a positive value");
      }
      this.source = source;
      this.destination = destination;
    }
  }

  /**
   * Class that implements and creates the adjacency matrix, which shows the connection between the
   * various nodes in a given matrix of elements.
   */
  public static class Graph {
    private int vertices;

    private List<ArrayList<Integer>> adj;
    private List<Edge> allEdges = new ArrayList<>();


    /**
     * Constructor to initialise the parameters of the graph.
     *
     * @param vertices the total number of nodes that are there in the graph.
     */
    public Graph(int vertices) {
      if (vertices < 0) {
        throw new IllegalArgumentException("vertice needs to be greater than 0");
      }
      this.vertices = vertices;
      adj = new ArrayList<ArrayList<Integer>>(vertices);
      for (int i = 0; i < vertices; ++i) {
        adj.add(new ArrayList<Integer>());
      }
    }

    /**
     * Function to add a connection between the source and node elements.
     *
     * @param source      first node
     * @param destination second node
     */
    public void addEgde(int source, int destination) {
      if (source < 0) {
        throw new IllegalArgumentException(" source needs to be greater than 0");
      }
      if (destination < 0) {
        throw new IllegalArgumentException("destination needs to be greater than 0");
      }
      Edge edge = new Edge(source, destination);

      allEdges.add(edge); //add to total edges
    }

    /**
     * Function to implement the kruskals algorithm to determine MST for the given graph. 1. Sort
     * all the edges in non-decreasing order of their weight. 2. Pick the smallest edge. Check if it
     * forms a cycle with the spanning tree formed so far. If cycle is not formed, include this
     * edge. Else, discard it. 3. Repeat step#2 until there are (V-1) edges in the spanning tree.
     *
     * @param interconnectivity to determine the number of paths possible
     */
    public void kruskalMst(int interconnectivity) {
      if (interconnectivity < 0) {
        throw new IllegalArgumentException("interconnectivity needs to be greater than 0");
      }
      Queue<Edge> pq = new LinkedList<>();
      List<Edge> allEdgesCopy = new ArrayList<>();
      for (Edge e : allEdges) {
        allEdgesCopy.add(e);
      }
      Collections.shuffle(allEdgesCopy);
      for (int i = 0; i < allEdges.size(); i++) {
        pq.add(allEdgesCopy.get(i));
      }

      //create a parent []
      int[] parent = new int[vertices];

      //makeset
      makeSet(parent);

      mst = new ArrayList<>();
      Stack<Edge> ignoreEdges = new Stack<>();

      //process vertices – 1 edges
      int index = 0;
      while (index < vertices - 1) {
        Edge edge = pq.remove();
        //check if adding this edge creates a cycle
        int x_set = find(parent, edge.source);
        int y_set = find(parent, edge.destination);

        if (x_set == y_set) {
          ignoreEdges.add(edge);
          //ignore, will create cycle
        } else {
          //add it to our final result
          mst.add(edge);
          index++;
          union(parent, x_set, y_set);
        }
      }
      while (interconnectivity > 0 && !ignoreEdges.isEmpty()) {
        Edge edge = ignoreEdges.pop();
        int x_set = find(parent, edge.source);
        int y_set = find(parent, edge.destination);
        mst.add(edge);
        index++;
        union(parent, x_set, y_set);
        interconnectivity--;
      }
      addAdj();
    }

    /**
     * Returns the mst for the given elemtns.
     *
     * @return mst
     */
    public List<Edge> getMst() {
      List<Edge> copymst = new ArrayList<>();
      for (Edge e : mst) {
        copymst.add(e);
      }

      return copymst;

    }

    /**
     * Add the source and destination to the adjacency list.
     */
    public void addAdj() {
      for (int i = 0; i < mst.size(); i++) {
        Edge edge = mst.get(i);
        adj.get(edge.source).add(edge.destination);
        adj.get(edge.destination).add(edge.source);
      }


    }

    /**
     * returns the adjacency list.
     *
     * @return adjacency list
     */
    public List<ArrayList<Integer>> getAdj() {
      List<ArrayList<Integer>> copyAdj = new ArrayList<>();
      for (ArrayList<Integer> a : adj) {
        copyAdj.add(a);
      }

      return copyAdj;
    }


    /**
     * Make set- creating a new element with a parent pointer to itself.
     *
     * @param parent parent
     */
    public void makeSet(int[] parent) {
      if (parent == null) {
        throw new IllegalArgumentException("Enter a valid value");

      }
      for (int i = 0; i < vertices; i++) {
        parent[i] = i;
      }
    }

    /**
     * chain of parent pointers from x upwards through the tree until an element is reached whose
     * parent is itself.
     *
     * @param parent parent
     * @param vertex vertex
     * @return vertex
     */
    public int find(int[] parent, int vertex) {
      if (parent == null) {
        throw new IllegalArgumentException("Please enter a valid value");
      }
      if (vertex < 0) {
        throw new IllegalArgumentException("Please enter a positive value");
      }
      if (parent[vertex] != vertex) {
        return find(parent, parent[vertex]);
      }
      int copyVertex;
      copyVertex = vertex;
      return copyVertex;
    }

    /**
     * make x as parent of y.
     *
     * @param parent parent
     * @param x      x
     * @param y      y
     */
    public void union(int[] parent, int x, int y) {
      if (parent == null) {
        throw new IllegalArgumentException("Please enter a valid value");
      }
      if (x < 0) {
        throw new IllegalArgumentException("Please enter a positive value");
      }
      if (y < 0) {
        throw new IllegalArgumentException("Please enter a positive value");
      }
      int x_set_parent = find(parent, x);
      int y_set_parent = find(parent, y);

      parent[y_set_parent] = x_set_parent;
    }


  }


}




