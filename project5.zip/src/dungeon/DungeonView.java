package dungeon;


import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

/**
 * Java class to create a dungeon view panel with various buttons implementing functionalities of
 * quit, restart ,etc.
 */
public class DungeonView extends JFrame implements IView {

  DungeonPanel panel;
  private JButton gameSettingButton;
  private JButton quitGameButton;
  private JButton restartButton;
  private JButton locationButton;
  private JButton descriptionButton;


  /**
   * Constructor to set up the GUI frame.
   *
   * @param title GUI title
   * @param m     Dungeon Model
   */
  public DungeonView(String title, DungeonModel m) {
    super(title);
    if (m == null) {
      throw new IllegalArgumentException("Invalid model");
    }
    int containerHeight = 600;
    int containerWidth = 1000;
    setSize(containerWidth, containerHeight);
    setLocation(200, 200);
    this.setResizable(false);

    this.setLayout(new BorderLayout());
    this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    panel = new DungeonPanel(m, this);

    JScrollPane scroll = new JScrollPane();
    scroll.setViewportView(panel);
    this.add(scroll);
    JPanel buttonPanel = new JPanel();
    gameSettingButton = new JButton("Setting");
    gameSettingButton.setActionCommand("setting");
    buttonPanel.add(gameSettingButton);

    quitGameButton = new JButton("Quit");
    quitGameButton.setActionCommand("quit");
    buttonPanel.add(quitGameButton);

    restartButton = new JButton("Restart");
    restartButton.setActionCommand("restart");
    buttonPanel.add(restartButton);

    locationButton = new JButton("Location Details");
    locationButton.setActionCommand("locationDetails");
    buttonPanel.add(locationButton);

    descriptionButton = new JButton("Player Description");
    descriptionButton.setActionCommand("descriptionDetails");
    buttonPanel.add(descriptionButton);


    this.add(buttonPanel, BorderLayout.EAST);
    this.setVisible(true);
  }

  /**
   * This class represents a keyboard listener. It is configurable by the controller that
   * instantiates it.
   *
   * <p>This listener keeps three maps, one each for key typed, key pressed and key
   * released Each map stores a key mapping. A key mapping is a pair (keystroke,code to be executed
   * with that keystroke) The latter part of that pair is actually a function object, i.e. an object
   * of a class that implements the Runnable interface
   *
   * <p>This class implements the KeyListener interface, so that its object can be
   * used as a valid key listener for Java Swing.
   */
  @Override
  public void setListeners(ActionListener clicks, KeyListener keys) {
    this.addKeyListener(keys);
    this.gameSettingButton.addActionListener(clicks);
    this.quitGameButton.addActionListener(clicks);
    this.restartButton.addActionListener(clicks);
    this.locationButton.addActionListener(clicks);
    this.descriptionButton.addActionListener(clicks);
    this.setFocusable(true);
    this.requestFocus();
  }


  /**
   * Function to refresh the screen each time a key is pressed or an action occurs to load the
   * screen with new content.
   */
  @Override
  public void refresh() {
    panel.removeAll();
    panel.setImages();
    panel.revalidate();
  }

  @Override
  public void resetFocus() {
    this.setFocusable(true);
    this.requestFocus();
  }


}
