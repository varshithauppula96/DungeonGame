package dungeon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Vector;


/**
 * Dungeon class to implement the dungeon interface which is used to represent a network of
 * connected caves and tunnels which a player can explore by travelling from cave to cave through
 * the tunnels that connect them. A dungeon can be wrapping or not and has imterconnectivity which
 * defines the number of paths between two points in the dungeon. There is treasure present in the
 * dungeon which can be collected by the player as he  s through the caves.
 */
public class DungeonModelClass implements DungeonModel {
  private final int[][] dung;
  private final dungeon.Cell[][] dungCellObject;
  private final List<dungeon.Caves> caveList;
  private final int width;
  private final int height;
  private int totalCaves;
  private final int v;
  private int start;
  private int end;
  private int interconnectivity;
  private int otyughCount;
  private HashMap<Integer, String> cellType;
  private int[][] adjMatrix;
  private List<ArrayList<Integer>> adjtemp;
  private Map<Integer, List<Integer>> matrixLoc;
  private Player player1;
  private int wrapping;
  private String smell;
  private int winner;
  private int percent;

  /**
   * Constructor to initialise the various parameters pertaining to a dungeon.
   *
   * @param width             width of dungeon
   * @param height            height of the dungeon
   * @param wrapping          wrapping or not
   * @param interconnectivity interconnectivity of dungeon
   */
  public DungeonModelClass(int width, int height, int wrapping, int interconnectivity) {
    if (width < 0) {
      throw new IllegalArgumentException("Enter a positive value for width");
    }
    if (height < 0) {
      throw new IllegalArgumentException("Enter a positive value for height");
    }

    if (!(wrapping == 1 || wrapping == 2)) {
      throw new IllegalArgumentException("PLease enter only 1 or 2 as option");
    }
    if (interconnectivity < 0) {
      throw new IllegalArgumentException("Enter a valid interconnectivity");
    }
    dung = new int[height][width];
    this.smell = "";
    dungCellObject = new dungeon.Cell[height][width];
    this.wrapping = wrapping;
    caveList = new ArrayList<>();
    this.width = width;
    this.height = height;
    totalCaves = 0;
    winner = 0;
    v = width * height;
    this.cellType = new HashMap<>();
    adjMatrix = new int[height][width];
    matrixLoc = new HashMap<>();
    Map<Integer, List<Integer>> matrixLoc = new HashMap<>();
    int vertices = width * height;
    KruskalsClass.Graph g1 = new KruskalsClass.Graph(vertices);
    KruskalsClass k1 = new KruskalsClass();
    this.otyughCount = 0;
    this.percent = 0;
    this.interconnectivity = interconnectivity;

    if (wrapping == 1) {
      for (int i = 0; i < width; i++) {
        g1.addEgde(i, vertices - width + i);
      }
      for (int j = 0; j < height; j++) {
        g1.addEgde((width * j), (width * j) + (height - 1));
      }
    }
    for (int i = 0; i < vertices - width; i++) {
      if ((i + 1) % width == 0) {
        g1.addEgde(i, i + width);
      } else {
        g1.addEgde(i, i + 1);
        g1.addEgde(i, i + width);
      }
    }
    for (int i = vertices - width; i < vertices - 1; i++) {
      g1.addEgde(i, i + 1);
    }

    adjtemp = g1.getAdj();
    g1.kruskalMst(this.interconnectivity);
    createMatrixName();
    createCell();


  }


  @Override
  public void createMatrixName() {
    int t = 0;
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        dung[i][j] = t;
        List<Integer> l1 = new ArrayList<>();
        l1.add(i);
        l1.add(j);
        matrixLoc.put(t, l1);
        t++;
      }
    }

  }

  @Override
  public void createCell() {
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        determineCellType();
        int cellId = dung[i][j];
        if (cellType.get(cellId).equals("Tunnel")) {
          dungeon.Cell c1 = new Tunnels(i, j, cellId);
          dungCellObject[i][j] = c1;
        } else {
          dungeon.Cell c2 = new dungeon.Caves(i, j, cellId);
          caveList.add((dungeon.Caves) c2);
          dungCellObject[i][j] = c2;
          totalCaves++;
        }
      }
    }
  }

  @Override
  public dungeon.Cell[][] getDungeonCell() {
    dungeon.Cell[][] copyDungeonCell =
            new dungeon.Cell[dungCellObject.length][dungCellObject[0].length];
    for (int i = 0; i < dungCellObject.length; i++) {
      for (int j = 0; j < dungCellObject[0].length; j++) {
        copyDungeonCell[i][j] = dungCellObject[i][j];
      }
    }
    return dungCellObject;

  }

  @Override
  public int[][] getDung() {
    int[][] copyDungeon = new int[dung.length][dung[0].length];
    for (int i = 0; i < dung.length; i++) {
      for (int j = 0; j < dung[0].length; j++) {
        copyDungeon[i][j] = dung[i][j];
      }
    }
    return copyDungeon;
  }

  @Override
  public List<dungeon.Caves> getCaveList() {
    List<dungeon.Caves> copyCavesList = new ArrayList<>();
    for (dungeon.Caves c : caveList) {
      copyCavesList.add(c);
    }

    return copyCavesList;
  }

  @Override
  public void assignTreasure(int treasurePercent) {
    if (treasurePercent < 0 || treasurePercent > 100) {
      throw new IllegalArgumentException("PLease enter value between 0 and 100");
    }
    percent = treasurePercent;
    int treasuredCaves;
    treasuredCaves = (treasurePercent * totalCaves) / 100;

    Random rand = new Random();
    while (treasuredCaves > 0) {

      int i = rand.nextInt(((height - 1) - 0) + 1) + 0;
      int j = rand.nextInt(((width - 1) - 0) + 1) + 0;
      dungCellObject[i][j].findConnectedCells(width, height, dung,
              adjtemp, wrapping);
      if (dungCellObject[i][j].getCellType().equals("Cave")) {
        dungCellObject[i][j].assignTreasure();
      }
      treasuredCaves--;
    }
  }

  @Override
  public void determineStartEnd() {
    int distance;
    Random rn = new Random();
    int vertice = width * height;
    Boolean flag = false;
    while (!flag) {
      int src = rn.nextInt(vertice - 1) + 0;
      int dest = rn.nextInt(vertice - 1) + 0;
      distance = determineDistance(adjtemp, src, dest, vertice);
      int cellType;
      List<Integer> currLoc = new ArrayList<>();
      currLoc = matrixLoc.get(src);
      int row = currLoc.get(0);
      int col = currLoc.get(1);

      List<Integer> currLoc2 = new ArrayList<>();
      currLoc2 = matrixLoc.get(dest);
      int row1 = currLoc2.get(0);
      int col1 = currLoc2.get(1);
      dungCellObject[row][col].findConnectedCells(width, height, dung,
              adjtemp, wrapping);
      dungCellObject[row1][col1].findConnectedCells(width, height, dung,
              adjtemp, wrapping);

      if (dungCellObject[row][col].getCellType().equals("Cave") && distance > 5
              && dungCellObject[row1][col1].getCellType().equals("Cave")) {
        {
          this.start = src;
          this.end = dest;
          //this.start = 10;
          //this.end = 11;
          flag = true;
        }
      }
    }
  }

  @Override
  public int getStart() {
    int copyStart;
    copyStart = start;
    return copyStart;
  }

  @Override
  public int getEnd() {
    int copyEnd;
    copyEnd = end;

    return copyEnd;
  }

  @Override
  public int determineDistance(List<ArrayList<Integer>> edges, int u, int v, int n) {
    if (edges == null) {
      throw new IllegalArgumentException("PLease enter non null edges");
    }
    if (u < 0) {
      throw new IllegalArgumentException("PLease enter positive nodes");
    }
    if (v < 0) {
      throw new IllegalArgumentException("PLease enter positive nodes");
    }
    if (n < 0) {
      throw new IllegalArgumentException("PLease enter positive value");
    }
    Vector<Boolean> visited = new Vector<Boolean>(n);

    for (int i = 0; i < n; i++) {
      visited.addElement(false);
    }

    Vector<Integer> distance = new Vector<Integer>(n);

    for (int i = 0; i < n; i++) {
      distance.addElement(0);
    }
    Queue<Integer> que = new LinkedList<>();
    distance.setElementAt(0, u);

    que.add(u);
    visited.setElementAt(true, u);
    while (!que.isEmpty()) {
      int x = que.peek();
      que.poll();

      for (int i = 0; i < edges.get(x).size(); i++) {

        if (visited.elementAt(edges.get(x).get(i))) {
          continue;
        }

        distance.setElementAt(distance.get(x) + 1, edges.get(x).get(i));
        que.add(edges.get(x).get(i));
        visited.setElementAt(true, edges.get(x).get(i));
      }
    }
    return distance.get(v);
  }

  @Override
  public void determineCellType() {
    for (int i = 0; i < v; i++) {
      int count = 0;
      for (int j : adjtemp.get(i)) {
        count++;
      }
      if (count == 2) {
        cellType.put(i, "Tunnel");
      } else {
        cellType.put(i, "Cave");


      }
    }
  }


  @Override
  public void findPossibleDirections() {

    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        dungCellObject[i][j].findConnectedCells(width, height, dung, adjtemp, wrapping);

      }
    }
  }

  @Override
  public void createConnectedMatrix() {
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        adjMatrix[i][j] = 0;
      }
    }
    for (int i = 0; i < v; i++) {
      List<Integer> elem = adjtemp.get(i);
      List<Integer> loc1 = matrixLoc.get(i);
      int r1 = loc1.get(0);
      int c1 = loc1.get(1);
      for (int j : elem) {

        List<Integer> loc = matrixLoc.get(j);
        int r = loc.get(0);
        int c = loc.get(1);
        adjMatrix[r][c] = 1;
        adjMatrix[r1][c1] = 1;
      }
    }

  }

  @Override
  public List<ArrayList<Integer>> getAdjacencyList() {
    List<ArrayList<Integer>> copyAdjList = new ArrayList<>();
    for (ArrayList<Integer> c : adjtemp) {
      copyAdjList.add(c);
    }

    return copyAdjList;
  }

  @Override
  public int[][] getAdjMatrix() {
    int[][] copyAdjMatrix = new int[adjMatrix.length][adjMatrix[0].length];
    for (int i = 0; i < adjMatrix.length; i++) {
      for (int j = 0; j < adjMatrix[0].length; j++) {
        copyAdjMatrix[i][j] = adjMatrix[i][j];
      }
    }
    return copyAdjMatrix;
  }

  @Override
  public Map<Integer, List<Integer>> getIndexOfNodes() {
    Map<Integer, List<Integer>> copyMatrixLoc = new HashMap<>();
    for (Map.Entry<Integer, List<Integer>> entry : matrixLoc.entrySet()) {
      copyMatrixLoc.put(entry.getKey(), entry.getValue());
    }
    return copyMatrixLoc;

  }

  @Override
  public void createPlayer() {
    player1 = new PlayerClass(1, "Player1", getStart(), getDung(), getDungeonCell(),
            getIndexOfNodes(), getAdjacencyList(), wrapping);
  }

  @Override
  public Player getPlayer() {
    Player p2;
    p2 = player1;
    return p2;
  }

  @Override
  public void createOtyughs(int otyughsCount) {
    if (otyughsCount < 0) {
      throw new IllegalArgumentException("Enter a positive number");
    }
    this.otyughCount = otyughsCount;
    List<Integer> currLoc = new ArrayList<>();
    currLoc = matrixLoc.get(getEnd());
    int t = 0;
    int i = currLoc.get(0);
    int j = currLoc.get(1);
    Otyughs o1 = new OtyughsClass(t, getEnd());
    dungCellObject[i][j].assignOtyughs(o1);
    t++;
    otyughsCount--;
    int cave = -1;
    // pick random cell, check if it is a cave, assign otyughs
    while (otyughsCount > 0) {
      Random rn = new Random();
      int vertice = width * height;
      // int cave = rn.nextInt(vertice - 1) + 0;
      if (cave < vertice - 1) {
        cave++;
      } else {
        cave = 0;
      }
      currLoc = new ArrayList<>();
      currLoc = matrixLoc.get(cave);
      i = currLoc.get(0);
      j = currLoc.get(1);
      if (currLoc != matrixLoc.get(getStart())) {
        dungCellObject[i][j].findConnectedCells(width, height, dung,
                adjtemp, wrapping);
        if (dungCellObject[i][j].getCellType().equals("Cave")) {
          o1 = new OtyughsClass(t, cave);
          dungCellObject[i][j].assignOtyughs(o1);
          t++;
          otyughsCount--;
        }

      }
    }
  }


  @Override
  public void determineSmell(int playerLoc) {
    if (playerLoc < 0) {
      throw new IllegalArgumentException("Enter a valid positive value");
    }
    int vertice = height * width;
    smell = "No Smell";
    for (int i = 0; i < vertice; i++) {
      int dist = determineDistance(adjtemp, playerLoc, i, vertice);
      List<Integer> currLoc = new ArrayList<>();
      //if dist = 2 then check how many otyhu are there in that loc.
      currLoc = new ArrayList<>();
      currLoc = matrixLoc.get(i);
      int row = currLoc.get(0);
      int col = currLoc.get(1);
      int otyCount = dungCellObject[row][col].getOtyughsCount();
      if (dist == 2 && otyCount == 1) {
        smell = "Less Pungent";
      } else if (dist == 2 && otyCount > 1) {
        smell = "More Pungent More Otyugh";
      } else if (dist == 1 && otyCount == 1) {
        smell = "More Pungent";
      }
    }


  }

  @Override
  public String getSmell() {
    return new String(smell);
  }

  @Override
  public void assignArrowsInCell(int arrowsPercent) {
    if (arrowsPercent < 0 || arrowsPercent > 100) {
      throw new IllegalArgumentException("PLease enter value between 0 and 100");
    }

    int arrowedCells;
    arrowedCells = (arrowsPercent * (height * width)) / 100;

    Random rand = new Random();
    while (arrowedCells > 0) {

      int i = rand.nextInt(((height - 1) - 0) + 1) + 0;
      int j = rand.nextInt(((width - 1) - 0) + 1) + 0;
      dungCellObject[i][j].findConnectedCells(width, height, dung,
              adjtemp, wrapping);

      dungCellObject[i][j].setIsArrowed(true);

      arrowedCells--;
    }
  }


  @Override
  public void determineWinner() {
    int currLoc = player1.getCurrentLocation();
    List<Integer> currentLoc = new ArrayList<>();
    currentLoc = matrixLoc.get(currLoc);
    int row = currentLoc.get(0);
    int col = currentLoc.get(1);
    int otyughsCount = dungCellObject[row][col].getOtyughsCount();
    if (otyughsCount > 1) {
      winner = 2;
    } else if (otyughsCount == 1) {
      Otyughs o1 = dungCellObject[row][col].getOtyughsAssigned().get(0);
      int health = o1.getOtyughHealth();
      if (health == 100) {
        winner = 2;
      } else if (health == 50) {
        Random rn = new Random();
        int range = 2 - 1 + 1;
        int randomNum = rn.nextInt(range) + 1;
        if (randomNum == 1) {
          winner = 2;
        } else {
          winner = 0;
        }
      }
    } else if (isReachedDest()) {
      winner = 1;
    }


  }

  @Override
  public boolean isReachedDest() {
    return (getPlayer().getCurrentLocation() == getEnd());
  }

  @Override
  public int getWinner() {
    int copyWinner;
    copyWinner = winner;
    return copyWinner;
  }

  @Override
  public boolean isPlayerAlive() {
    determineWinner();
    return (getWinner() != 2);
  }

  @Override
  public int getWidth() {
    int copyWidth;
    copyWidth = width;
    return copyWidth;
  }

  @Override
  public int getHeight() {
    int copyHeight;
    copyHeight = height;
    return copyHeight;
  }

  @Override
  public int getWrapping() {
    int copyWrapping;
    copyWrapping = wrapping;
    return copyWrapping;
  }

  @Override
  public int getLocRow(int playerLoc) {
    if (playerLoc < 0) {
      throw new IllegalArgumentException("Enter a valid positive value");
    }
    List<Integer> currLoc = new ArrayList<>();
    currLoc = matrixLoc.get(playerLoc);
    int row = currLoc.get(0);
    return row;
  }

  @Override
  public int getLocCol(int playerLoc) {
    if (playerLoc < 0) {
      throw new IllegalArgumentException("Enter a valid positive value");
    }
    List<Integer> currLoc = new ArrayList<>();
    currLoc = matrixLoc.get(playerLoc);
    int col = currLoc.get(1);
    return col;
  }

  @Override
  public int getOtyughCount() {
    int otyughCountCopy;
    otyughCountCopy = otyughCount;
    return otyughCountCopy;
  }

  @Override
  public int getTreasurePercent() {
    int treasurePercentCopy;
    treasurePercentCopy = percent;
    return treasurePercentCopy;
  }

  @Override
  public int getInterconnectivity() {
    int interconnectivityCopy;
    interconnectivityCopy = interconnectivity;
    return interconnectivityCopy;
  }

}



