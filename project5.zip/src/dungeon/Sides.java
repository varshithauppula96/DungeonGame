package dungeon;

/**
 * Enum to represent the four possible directions in which a given cell in a dungeon is connected.
 */
public enum Sides {
  NORTH, SOUTH, EAST, WEST
}
