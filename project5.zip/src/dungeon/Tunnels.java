package dungeon;

/**
 * Class which represents a cell of type Tunnels.Tunnels have only two entrances and cannot have any
 * treasure placed in them.
 */
public class Tunnels extends AbstractCell {

  /**
   * Tunnel class of type cell which has only 2 entrances.Tunnel cannot have treasure assigned in
   * them.
   *
   * @param col    colId of Cell
   * @param row    rowId of Cell
   * @param cellId cellId
   */
  public Tunnels(int col, int row, int cellId) {
    super(col, row, cellId);
  }


}
