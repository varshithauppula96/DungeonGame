package dungeon;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Scanner;

import javax.swing.JOptionPane;

/**
 * Controller of MVC model to interact with user to play the model to move the player through the *
 * dungeon to reach the end using GUI.
 */
public class DungeonGraphicalController implements ActionListener, KeyListener {
  private DungeonModel model;
  private DungeonView view;
  private int dist = 0;
  private boolean flag = false;
  private Sides arrowSide = null;

  DungeonGraphicalController(DungeonModel m, DungeonView v) {
    if (m == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (v == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    this.model = m;
    this.view = v;
    view.setListeners(this, this);

  }


  @Override
  public void keyTyped(KeyEvent e) {
    if (e.getKeyChar() == 'q') {
      JOptionPane.showMessageDialog(view.panel,
              "Q pressed");
    }
  }

  @Override
  public void keyPressed(KeyEvent e) {
    if (e == null) {
      throw new IllegalArgumentException("Invalid key event");
    }
    view.refresh();

    if (e.getKeyCode() == KeyEvent.VK_N) {
      try {
        model.getPlayer().movePlayer(Sides.NORTH);
        JOptionPane.showMessageDialog(view.panel,
                "Moved player North");

      } catch (Exception x) {
        System.out.println("Cant move player north");
        JOptionPane.showMessageDialog(view.panel,
                "Cant move player north");
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_S) {
      try {
        model.getPlayer().movePlayer(Sides.SOUTH);
        JOptionPane.showMessageDialog(view.panel,
                "Moved player South");
      } catch (Exception x) {
        System.out.println("Cant move player South");
        JOptionPane.showMessageDialog(view.panel,
                "Can't move player South");
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_E) {
      try {
        model.getPlayer().movePlayer(Sides.EAST);
        JOptionPane.showMessageDialog(view.panel,
                "Moved player East");
      } catch (Exception x) {
        System.out.println("Cant move player East");
        JOptionPane.showMessageDialog(view.panel,
                "Cant move player East");
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_W) {
      try {
        model.getPlayer().movePlayer(Sides.WEST);
        JOptionPane.showMessageDialog(view.panel,
                "Moved player West");
      } catch (Exception x) {
        System.out.println("Cant move player West");
        JOptionPane.showMessageDialog(view.panel,
                "Cant move player West");
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_T) {
      try {
        model.getPlayer().pick("Treasure");
        JOptionPane.showMessageDialog(view.panel,
                "Picked up treasure");
      } catch (Exception x) {
        System.out.println("Cant pick treasure");
        JOptionPane.showMessageDialog(view.panel,
                "Cant pick treasure");
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_A) {
      try {
        model.getPlayer().pick("Arrow");
        JOptionPane.showMessageDialog(view.panel,
                "Picked up Arrow");
      } catch (Exception x) {
        System.out.println("Cant pick arrow");
        JOptionPane.showMessageDialog(view.panel,
                "Cant pick arrow");
      }
    }

    if (e.getKeyCode() == KeyEvent.VK_LEFT) {
      flag = true;
      arrowSide = Sides.WEST;
      JOptionPane.showMessageDialog(view.panel,
              "Enter the distance to shoot arrow in West");
    }
    if (e.getKeyCode() == KeyEvent.VK_UP) {
      flag = true;
      arrowSide = Sides.NORTH;
      JOptionPane.showMessageDialog(view.panel,
              "Enter the distance to shoot arrow in North");
    }
    if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
      flag = true;
      arrowSide = Sides.EAST;
      JOptionPane.showMessageDialog(view.panel,
              "Enter the distance to shoot arrow in East");
    }
    if (e.getKeyCode() == KeyEvent.VK_DOWN) {
      flag = true;
      arrowSide = Sides.SOUTH;
      JOptionPane.showMessageDialog(view.panel,
              "Enter the distance to shoot arrow in South");
    }
    if (e.getKeyCode() == KeyEvent.VK_1 && flag) {
      dist = 1;
      try {
        model.getPlayer().slayOtyugh(arrowSide, dist);
        flag = false;

      } catch (Exception x) {
        System.out.println("Error caught");
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_2 && flag) {
      dist = 2;
      try {
        model.getPlayer().slayOtyugh(arrowSide, dist);
        flag = false;

      } catch (Exception x) {
        System.out.println("Error caught");
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_3 && flag) {
      dist = 3;
      try {
        model.getPlayer().slayOtyugh(arrowSide, dist);
        flag = false;

      } catch (Exception x) {
        System.out.println("Error caught");
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_4 && flag) {
      dist = 4;
      try {
        model.getPlayer().slayOtyugh(arrowSide, dist);
        flag = false;

      } catch (Exception x) {
        System.out.println("Error caught");
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_5 && flag) {
      dist = 5;
      try {
        model.getPlayer().slayOtyugh(arrowSide, dist);
        flag = false;

      } catch (Exception x) {
        System.out.println("Error caught");
      }
    }

    model.determineWinner();
    if (model.getWinner() == 1) {
      JOptionPane.showMessageDialog(view.panel,
              "Player Won the Game!");
      view.refresh();
    } else if (model.getWinner() == 2) {
      JOptionPane.showMessageDialog(view.panel,
              "Otyugh Won the game!");
      view.refresh();
    }


    view.refresh();
  }


  @Override
  public void keyReleased(KeyEvent e) {
    if (e == null) {
      throw new IllegalArgumentException("Invalid key event");
    }
    if (e.getKeyCode() == KeyEvent.VK_N || e.getKeyCode() == KeyEvent.VK_S
            || e.getKeyCode() == KeyEvent.VK_E || e.getKeyCode() == KeyEvent.VK_W
            || e.getKeyCode() == KeyEvent.VK_T || e.getKeyCode() == KeyEvent.VK_A
            || e.getKeyCode() == KeyEvent.VK_KP_LEFT || e.getKeyCode() == KeyEvent.VK_UP
            || e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_DOWN
            || e.getKeyCode() == KeyEvent.VK_1 || e.getKeyCode() == KeyEvent.VK_2
            || e.getKeyCode() == KeyEvent.VK_3 || e.getKeyCode() == KeyEvent.VK_4
            || e.getKeyCode() == KeyEvent.VK_5) {
      view.refresh();
    }
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      // read from the input text field
      case "setting":
        StringBuilder str1 = new StringBuilder();
        str1.append("Size of Dungeon is " + model.getHeight() + "X" + model.getWidth());
        str1.append("\n");
        str1.append("Interconnectivity " + model.getInterconnectivity());
        str1.append("\n");
        if (model.getWrapping() == 1) {
          str1.append("Dungeon is Wrapping");
        } else if (model.getWrapping() == 2) {
          str1.append("Dungeon is non Wrapping");
        }
        str1.append("\n");
        str1.append("Number of Otyughs " + model.getOtyughCount());
        str1.append("\n");

        str1.append("Percentage of caves that have treasure and arrows in them "
                + model.getTreasurePercent());
        str1.append("\n");
        JOptionPane.showMessageDialog(view.panel,
                str1);
        break;
      case "quit":
        System.exit(0);
        break;

      case "locationDetails":
        StringBuilder str2 = new StringBuilder();
        model.getPlayer().setPossibleMoves();
        str2 = model.getPlayer().getPLayerLocationDesc();
        model.determineSmell(model.getPlayer().getCurrentLocation());
        str2.append("Smell in room: " + model.getSmell());
        str2.append("\n");
        JOptionPane.showMessageDialog(view.panel,
                str2);

        break;
      case "descriptionDetails":
        StringBuilder str3 = new StringBuilder();
        str3 = model.getPlayer().getDescription();
        JOptionPane.showMessageDialog(view.panel,
                str3);
        break;
      case "restart":
        view.dispose();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter 1 to create a Wrapping Dungeon and 2 for creating a "
                +
                "non-wrapping Dungeon");
        int wrapping = scanner.nextInt();
        System.out.println("Enter the size of the Dungeon width and height");
        int col = scanner.nextInt();
        int row = scanner.nextInt();
        System.out.println("Enter the Interconnectivity");
        int interconnectivity = scanner.nextInt();

        DungeonModel model1 = new DungeonModelClass(col, row, wrapping, interconnectivity);
        model1.determineStartEnd();
        model1.createPlayer();
        System.out.println("Enter the otyugh count");
        int otyugh = scanner.nextInt();
        model1.createOtyughs(otyugh);
        System.out.println("Enter the percentage of treasure and arrows");
        int percent = scanner.nextInt();
        model1.assignArrowsInCell(percent);
        model1.assignTreasure(percent);
        System.out.println("Start" + model1.getStart());
        System.out.println("End" + model1.getEnd());
        DungeonGraphicalController controller = new DungeonGraphicalController(model1,
                new DungeonView("Dungeon Game", model1));
        break;

      default:
        throw new IllegalStateException("Error: Unknown button");

    }
    view.resetFocus();
  }


}
