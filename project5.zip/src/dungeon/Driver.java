package dungeon;

import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * Driver Class to implement the dungeon model end to end.
 */
public class Driver {
  /**
   * The main point of entry into the program.
   *
   * @param args array of sequence of charecters
   */
  public static void main(String[] args) {

    Readable input = new InputStreamReader(System.in);
    Appendable output = System.out;

    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter 1 to create a Wrapping Dungeon and 2 for creating a "
            +
            "non-wrapping Dungeon");
    int wrapping = scanner.nextInt();
    System.out.println("Enter the size of the Dungeon width and height");
    int col = scanner.nextInt();
    int row = scanner.nextInt();
    System.out.println("Enter the Interconnectivity");
    int interconnectivity = scanner.nextInt();

    DungeonModel model = new DungeonModelClass(col, row, wrapping, interconnectivity);
    model.determineStartEnd();
    model.createPlayer();
    System.out.println("Enter the otyugh count");
    int otyugh = scanner.nextInt();
    model.createOtyughs(otyugh);
    System.out.println("Enter the percentage of treasure and arrows");
    int percent = scanner.nextInt();
    model.assignArrowsInCell(percent);
    model.assignTreasure(percent);
    System.out.println("Start" + model.getStart());
    System.out.println("End" + model.getEnd());
    DungeonGraphicalController controller = new DungeonGraphicalController(model,
            new DungeonView("Dungeon Game", model));


  }
}


