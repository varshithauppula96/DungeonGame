package dungeon;

import java.util.List;
import java.util.Map;

/**
 * Interface to implement a player in the Dungeon world. PLayer is placed in a cave which is decided
 * as the start in the dungeon. Player can move in the possible direction from a given location to
 * reach the end point. While moving through the dungeon player can collect treasure.
 */
public interface Player {

  /**
   * Getter method to return the player ID.
   *
   * @return playerID
   */
  public int getPlayerID();

  /**
   * Getter method to get Name of player.
   *
   * @return name of player
   */
  public String getName();

  /**
   * description of the player that, that includes a description of what treasure the player has
   * collected, player name, player ID.
   *
   * @return Descriotion
   */
  public StringBuilder getDescription();

  /**
   * Returns the quantity of treasure collected for each type of treasure.
   *
   * @return Treasure collected
   */
  public Map<Treasure, Integer> getTreasureCollected();

  /**
   * Returns the current location in the dungeon for a player.
   *
   * @return Current location
   */
  public int getCurrentLocation();

  /**
   * Function to collect the treasure that is present in the given location.
   */
  public void addTreasureCollected();

  /**
   * Function to move the player in the dungeon based on the side provided if there is a valid
   * path.
   *
   * @param side Enum type side - NORTH, SOUTH,EAST ,WEST
   */
  public void movePlayer(Sides side);

  /**
   * Return the possible moves in the north, south, east, west direction.
   */
  public void setPossibleMoves();

  /**
   * Description of the player's location that includes a description of treasure in the room and
   * the possible moves (north, east, south, west) that the player can make from their current
   * location.
   *
   * @return Location description
   */
  public StringBuilder getPLayerLocationDesc();

  /**
   * Getter method to return the possible side connections for a given cell.
   *
   * @return possible sides
   */
  public List<Sides> getSidesList();

  /**
   * return the treasure present in a given cell.
   *
   * @return treasure in cell
   */
  public List<Treasure> getTreasureInCell();

  /**
   * Function to add arrow to the player arrow collection.
   */
  public void addArrowList();

  /**
   * Return the count of arrows the player has.
   *
   * @return arrow count
   */
  public int getPlayerArrowCount();

  /**
   * Function to kill an Otyugh by specifying a direction and distance in which to shoot their
   * crooked arrow. Distance is defined as the number of caves (but not tunnels) that an arrow
   * travels.
   *
   * @param initialDirection initial direction
   * @param distance         distance arrow can travel
   */
  public String slayOtyugh(Sides initialDirection, int distance);

  /**
   * Function to return the locartion of the arrow.
   *
   * @return location
   */
  public int getArrowCurrenLoc();

  /**
   * Function to return the possible arrow moves.
   */
  public void setPossibleArrowMoves();

  /**
   * Function that checks if a given cell is of type tunnel or cell.
   *
   * @return cell type
   */
  public String determineCellType();

  /**
   * Function to find the possible exits from a given cell and display it to user to enable them to
   * move.
   *
   * @return Possible exits
   */
  public String printExits();

  /**
   * Function that checks if treasure or arrows need to be picked and picks them.
   *
   * @param item item to be picked
   * @return String indicating if item is picked
   */
  public String pick(String item);

  /**
   * Function which returns true if Otyugh exists in the particular cell, else returns a false.
   *
   * @return flag to indicate Otyugh
   */
  public boolean checkOtyughExist();

  /**
   * Function to set the visited flag for each cell when a player visits that particular cell.
   */
  public void determineCellVisited();
}
