package dungeon;

import java.util.ArrayList;
import java.util.List;

/**
 * Interface to represent a cell in a Dungeon. A cell can either be a cave or a tunnel depending on
 * the number of connectedCells it has. If the number of connectedCells are 1,3,4 then it is a cave,
 * else its a tunnel.
 */
public interface Cell {

  /**
   * Function to find the cells that are connected to a given cell. This can be used to determine if
   * a cell is cave or tunnel. This information is also used to determine the possible moves from a
   * given cell depending on its connections.
   *
   * @param width   number of col in the dungeon
   * @param height  number of rows in the dungeon
   * @param dung    dungeon matrix represented by numbers
   * @param adjtemp adjacency list showing the connections between the cells in the dungeon
   */
  public void findConnectedCells(int width, int height, int[][] dung,
                                 List<ArrayList<Integer>> adjtemp, int wrap);

  /**
   * Function to Determine if given cell is a tunnel or a cave based on the number of connected
   * sides.
   */
  public void findCellType();

  /**
   * returns the rowID of a given cell.
   *
   * @return rowId
   */
  public int getRow();

  /**
   * returns the CellID of a given Cell.
   *
   * @return cellId
   */
  public int getCol();

  /**
   * returns the cellID for a given cell.
   *
   * @return cellID
   */
  public int getCellId();

  /**
   * Getter function to get cell type.
   *
   * @return Type of cell - Tunnel or Cave
   */
  public String getCellType();

  /**
   * Function to determine the connected sides.
   *
   * @return List of connected sides
   */
  public List<Sides> getConnectedSides();

  /**
   * Function to assign random number of treasure upto 10 to a particular cave.
   */
  public void assignTreasure();

  /**
   * function to check if given cave has treasure and mark the flag accordingly.
   */
  public void isTreasured();

  /**
   * Getter method to return the flag which determines if the given cave has treasure or not.
   *
   * @return treasure flag
   */
  public boolean getIsTreasured();

  /**
   * Function to remove treasure from the cave when player collects it from given cave.
   */
  public void updateTreasure();

  /**
   * Getter method to return the treasure present in a given cave.
   *
   * @return treasure assigned to cave
   */
  public List<Treasure> getTreasure();

  /**
   * Function to create and assign the otyugh monsters.
   *
   * @param otyughId otyugh id
   */
  public void assignOtyughs(Otyughs otyughId);

  /**
   * Function to check if a particular cell contains an otyugh.
   */
  public void isMonstered();

  /**
   * Returns the count of otyughs that are present in a particular cell.
   *
   * @return count of Otyughs
   */
  public int getOtyughsCount();

  /**
   * function that keeps track of flag to indiocate if a partiular cell has an arrow in it or not.
   *
   * @param arrowValue boolean true or false
   */
  public void setIsArrowed(Boolean arrowValue);

  /**
   * Getter function to indicate if a particular cell has an arrow assigned to it.
   *
   * @return boolean flag
   */
  public Boolean getIsArrowed();

  /**
   * Function to update the Otyugh count as and when they are slayed.
   */
  public void updateOtyughsCount();

  /**
   * Function to update health of Otyugh. Initial health of 100 is reduced by 50 everytime the
   * otyugh is slayed.
   */
  public void setHealth();

  /**
   * Function to return the otyughs that are assigned in the given cell.
   *
   * @return list of otyugh objects
   */
  public List<Otyughs> getOtyughsAssigned();


  /**
   * Function to set boolean flag when player visits a given cell.
   */
  public void setVisitedFlag();

  /**
   * Getter function to return the visited flag details.
   *
   * @return boolean flag
   */
  public boolean getVisitedFlag();
}
