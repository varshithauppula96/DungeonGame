package dungeon;

/**
 * Enum representing the different kinds of treasure that can be present in a cave.
 */
public enum Treasure {
  DIAMONDS, RUBIES, SAPPHIRES
}
