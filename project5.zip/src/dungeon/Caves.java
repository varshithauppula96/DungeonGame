package dungeon;


/**
 * Class to represent a cave. Cave can have one or more treasure assigned to them and have 1,3 or 4
 * entrances.
 */
public class Caves extends dungeon.AbstractCell {

  /**
   * Constructor to initialise the col, row and cellId of a cave.
   *
   * @param col    coldId
   * @param row    rowId
   * @param cellId cellId
   */
  public Caves(int col, int row, int cellId) {
    super(col, row, cellId);

  }


}
