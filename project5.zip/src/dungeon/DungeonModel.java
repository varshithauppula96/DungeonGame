package dungeon;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Dungeon interface to represent a network of connected caves and tunnels which a player can
 * explore by travelling from cave to cave through the tunnels that connect them. A dungeon can be
 * wrapping or not and has imterconnectivity which defines the number of paths between two points in
 * the dungeon. There is treasure present in the dungeon which can be collected by the player as he
 * moves through the caves.
 */
public interface DungeonModel {
  /**
   * Function to assign values to the matrix to enable easy representation. element at row 0, col 0
   * is represented as 0, row 0 col 1 as 1 and so on.
   */
  public void createMatrixName();

  /**
   * Creates the different types of cells - caves and tunnels.
   */
  public void createCell();

  /**
   * returns a cell object at a given location in the matrix.
   *
   * @return dungeonCell
   */
  public dungeon.Cell[][] getDungeonCell();

  /**
   * returns the matrix after naming it as 0,1,2 etc.
   *
   * @return the matrixName
   */
  public int[][] getDung();

  /**
   * Getter method that returns the cave object list.
   *
   * @return cave objects
   */
  public List<dungeon.Caves> getCaveList();

  /**
   * Function to assign treasure to random caves bases on the percentage input given by the user.
   *
   * @param treasurePercent percentage of treasure to be assigned
   */
  public void assignTreasure(int treasurePercent);

  /**
   * Function to determine the start and end locations in the dungeon. A min distance of 5 needs to
   * exist between the start and end. BFS is used to traverse and find the shortest distance between
   * two points and determine the start and end.
   */
  public void determineStartEnd();

  /**
   * Getter method to return the start.
   *
   * @return start
   */
  public int getStart();

  /**
   * Getter method to return end.
   *
   * @return end
   */
  public int getEnd();

  /**
   * Function to determine the distance between two points based on the bfs traversal.
   *
   * @param edges adjacency list of elements connected
   * @param u     start node
   * @param v     end node
   * @param n     no of vertices
   * @return distance
   */
  public int determineDistance(List<ArrayList<Integer>> edges, int u, int v, int n);

  /**
   * Function to check if a given cell is of type tunnel or cave based on the number of entrances.
   */
  public void determineCellType();

  /**
   * function to find the possible diretions (north, south, east, west) from a given cell.
   */
  public void findPossibleDirections();

  /**
   * create a matrix with elements as 1 everytime there is a connection between nodes. If all the
   * elements in the matrix are 1, then that means every element is connected to another element in
   * the dungeon.
   */
  public void createConnectedMatrix();

  /**
   * Function to return the adjacency list that shows the connection between the nodes. This is
   * generated after the dungeon is created using the kruskals algorithm.
   *
   * @return adjacency list
   */
  public List<ArrayList<Integer>> getAdjacencyList();

  /**
   * Returns the matrix that shows if two nodes are connected to each other.
   *
   * @return connected matrix
   */
  public int[][] getAdjMatrix();

  /**
   * Function to store the row and col values for a given index in the dungeon.
   *
   * @return hashmap of row and col for given index
   */
  public Map<Integer, List<Integer>> getIndexOfNodes();

  /**
   * Function to create a player for thw dungeon.
   */
  public void createPlayer();

  /**
   * getter function to return the player object.
   *
   * @return player object
   */
  public Player getPlayer();

  /**
   * Function to create Otyugh object and assign it to a particular cell based on the count.
   *
   * @param otyughsCount number of Otyugh to be created
   */
  public void createOtyughs(int otyughsCount);

  /**
   * Function to determine the smell as More-Pungent, Less pungent or no smell depending on location
   * and number of Otyughs.
   *
   * @param playerLoc Location of player in the dungeon
   */
  public void determineSmell(int playerLoc);

  /**
   * Getter function to return the smell based on Otyughs location and count.
   *
   * @return smell
   */
  public String getSmell();

  /**
   * function to assign arrows in the dungeon cells based on the percemtage given by user.
   *
   * @param arrowsPercent percentage of arrows to be assigned
   */
  public void assignArrowsInCell(int arrowsPercent);

  /**
   * Function to determine the winner. PLayer is the winner if he reaches the end destination
   * without getting killed by an otyughs.Player has 50 percent chance of escaping if he hits a
   * Otyugh one time and can kill the otyugh if he hits it twice.
   */
  public void determineWinner();

  /**
   * Getter function to find the winner as player Represented as 1, Otyugh represented as 2 and none
   * as 0.
   *
   * @return winner
   */
  public int getWinner();

  /**
   * Function that checks if destination is reached and returns true if it reached else returns
   * false.
   *
   * @return Boolean flag
   */
  public boolean isReachedDest();

  /**
   * Function that checks if player is still alive and returns true if he is, else returns false.
   *
   * @return flsg to indicate if player is alive
   */
  public boolean isPlayerAlive();

  /**
   * Getter funtion to return the height of the dungeon.
   *
   * @return dungeon height
   */
  public int getHeight();

  /**
   * Getter function to return the width of the dungeon.
   *
   * @return dungeon width
   */
  public int getWidth();

  /**
   * Getter function to return if dungeon is wrapping or not.
   *
   * @return wrapping details
   */
  public int getWrapping();

  /**
   * Function to return the row details of a given position in matrix.
   *
   * @param playerLoc players location
   * @return row details in matrix
   */
  public int getLocRow(int playerLoc);

  /**
   * Function to return the col details of a given position in matrix.
   *
   * @param playerLoc players location
   * @return col details in matrix
   */
  public int getLocCol(int playerLoc);

  /**
   * Getter function to return the total count of Otyugh present in the dungeon.
   *
   * @return Count of Otyugh
   */
  public int getOtyughCount();

  /**
   * Getter function to return the percentage of caves that have treasure.
   *
   * @return treasure percent
   */
  public int getTreasurePercent();

  /**
   * Getter function to return the interconnectivity.
   *
   * @return interconnectivity
   */
  public int getInterconnectivity();
}
