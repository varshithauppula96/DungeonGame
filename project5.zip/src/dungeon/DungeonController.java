package dungeon;


/**
 * Represents controller for the dungeon game Playing the game is handled through model.
 */
public interface DungeonController {

  /**
   * Execute a single game DungeonGame given a model. When game is over the playgame method ends.
   *
   * @param model - a non null dungeon game model
   */

  void playGame(DungeonModel model);


}

