package dungeon;

/**
 * Interface to implement the Otyugh are extremely smelly creatures that lead solitary lives in the
 * deep, dark places of the world like our dungeon.
 */
public interface Otyughs {
  /**
   * Determine the health of Otyugh based on attack by player.
   */
  public void setOtyughsHealth();

  /**
   * Getter function to return the otyugh health.
   *
   * @return Otyugh Health
   */
  public int getOtyughHealth();

  /**
   * Get the location details of Otyugh.
   *
   * @return Location id
   */
  public int getLocationId();

  /**
   * Function to set health of Otyugh.
   *
   * @param health health of Otyugh
   */
  public void setOtyughHealth(int health);
}
