package dungeon;


import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


/**
 * Java class to create the dungeon GUI Panel with a grid layout and buttons and images representing
 * each cell in the dungeon.
 */
public class DungeonPanel extends JPanel {

  private DungeonModel m;
  private JPanel buttonPanel;

  private JPanel panel = new JPanel();

  DungeonPanel(DungeonModel model, JFrame jframe) {
    if (model == null) {
      throw new IllegalArgumentException("Enter a valid model");
    }
    if (jframe == null) {
      throw new IllegalArgumentException("Enter a valid frame");
    }
    this.m = model;
    GridLayout grid = new GridLayout(m.getHeight(), m.getWidth());
    this.setSize(new Dimension(jframe.getWidth(), jframe.getHeight()));
    setLayout(grid);
    this.setImages();
  }

  /**
   * Function to set the different images for each row and cell in the dungeon.
   */
  public void setImages() {
    dungeon.Cell[][] dungCellObject = m.getDungeonCell();
    for (int i = 0; i < m.getHeight(); i++) {
      for (int j = 0; j < m.getWidth(); j++) {

        BufferedImage imageCell = null;
        BufferedImage imagePlayer = null;
        BufferedImage imageOtyugh = null;
        BufferedImage imageWeekSmell = null;
        BufferedImage imageStrongSmell = null;
        BufferedImage imageTreasureDiamond = null;
        BufferedImage imageTreasureRuby = null;
        BufferedImage imageTreasureSaphire = null;
        BufferedImage imageArrow = null;
        JLabel l = new JLabel();
        JLabel c = new JLabel();
        JLabel p = new JLabel();
        p.setSize(new Dimension(this.getWidth() / m.getHeight(), this.getHeight() / m.getWidth()));


        if (m.getWinner() == 1 || m.getWinner() == 2) {
          try {
            imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\black.png"));
          } catch (IOException e) {
            e.printStackTrace();
          }
        } else if (!dungCellObject[i][j].getVisitedFlag()) {
          try {
            imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\black.png"));
          } catch (IOException e) {
            e.printStackTrace();
          }
        } else if (dungCellObject[i][j].getVisitedFlag()) {
          if (dungCellObject[i][j].getOtyughsCount() > 0) {
            try {
              imageOtyugh = ImageIO.read(new File("src\\dungeon-images-bw\\otyugh.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (dungCellObject[i][j].getIsArrowed()) {
            try {
              imageArrow = ImageIO.read(new File("src\\dungeon-images-bw\\arrow-black.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }


          m.determineSmell(m.getPlayer().getCurrentLocation());
          if (m.getSmell().equals("More Pungent More Otyugh")) {
            try {
              imageStrongSmell = ImageIO.read(new File("src\\dungeon-images-bw\\stench02.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          } else if (m.getSmell().equals("More Pungent")) {
            try {
              imageStrongSmell = ImageIO.read(new File("src\\dungeon-images-bw\\stench02.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          } else if (m.getSmell().equals("Less Pungent")) {
            try {
              imageWeekSmell = ImageIO.read(new File("src\\dungeon-images-bw\\stench01.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }


          List<Treasure> treasureList;
          treasureList = dungCellObject[i][j].getTreasure();
          for (Treasure t : treasureList) {
            try {
              if (t == Treasure.DIAMONDS) {
                imageTreasureDiamond = ImageIO.read(new File("src\\"
                        +
                        "dungeon-images-bw\\diamond.png"));
              }
              if (t == Treasure.RUBIES) {
                imageTreasureRuby = ImageIO.read(new File("src\\"
                        +
                        "dungeon-images-bw\\ruby.png"));

              }
              if (t == Treasure.SAPPHIRES) {
                imageTreasureSaphire = ImageIO.read(new File("src\\"
                        +
                        "dungeon-images-bw\\emerald.png"));

              }
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          dungCellObject[i][j].findConnectedCells(m.getWidth(), m.getHeight(), m.getDung(),
                  m.getAdjacencyList(), m.getWrapping());
          List<Sides> sideList = dungCellObject[i][j].getConnectedSides();
          if (sideList.contains(Sides.NORTH)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\N.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.SOUTH)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\S.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.EAST)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\E.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.WEST)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\W.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }

          if (sideList.contains(Sides.NORTH) && sideList.contains(Sides.SOUTH)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\NS.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.NORTH) && sideList.contains(Sides.EAST)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\NE.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }

          if (sideList.contains(Sides.NORTH) && sideList.contains(Sides.WEST)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\WN.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }

          if (sideList.contains(Sides.EAST) && sideList.contains(Sides.SOUTH)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\ES.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.WEST) && sideList.contains(Sides.SOUTH)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\SW.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.EAST) && sideList.contains(Sides.WEST)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\EW.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.NORTH) && sideList.contains(Sides.SOUTH)
                  && sideList.contains(Sides.WEST)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\SWN.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.EAST) && sideList.contains(Sides.SOUTH)
                  && sideList.contains(Sides.WEST)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\ESW.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.NORTH) && sideList.contains(Sides.EAST)
                  && sideList.contains(Sides.WEST)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw\\NEW.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.NORTH) && sideList.contains(Sides.SOUTH)
                  && sideList.contains(Sides.EAST)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw"
                      +
                      "\\NES.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          if (sideList.contains(Sides.NORTH) && sideList.contains(Sides.SOUTH)
                  && sideList.contains(Sides.WEST)
                  && sideList.contains(Sides.EAST)) {
            try {
              imageCell = ImageIO.read(new File("src\\dungeon-images-bw"
                      +
                      "\\NESW.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          int currLoc = m.getPlayer().getCurrentLocation();
          int row = m.getLocRow(currLoc);
          int col = m.getLocCol(currLoc);
          if (row == i && col == j) {
            try {
              imagePlayer = ImageIO.read(new File("src\\dungeon-images-bw\\player.png"));
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
        }
        BufferedImage combinedImage = null;
        combinedImage = new BufferedImage(this.getWidth() / m.getHeight(),
                this.getHeight() / m.getWidth(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = combinedImage.createGraphics();
        g.drawImage(imageCell, 0, 0, this.getWidth() / m.getHeight(),
                this.getHeight() / m.getWidth(), null);
        g.drawImage(imageTreasureDiamond, 45, 30, 16, 16, null);
        g.drawImage(imageTreasureRuby, 40, 26, 16, 16, null);
        g.drawImage(imageTreasureSaphire, 35, 25, 16, 16, null);
        g.drawImage(imageOtyugh, 70, 45, 40, 40, null);
        g.drawImage(imageArrow, 50, 62, 13, 13, null);
        g.drawImage(imageWeekSmell, 25, 20, 64, 64, null);
        g.drawImage(imageStrongSmell, 25, 20, 64, 64, null);
        g.drawImage(imagePlayer, 60, 55, 40, 40, null);
        g.dispose();
        l.setIcon(new ImageIcon(combinedImage));
        this.add(l);
        validate();
      }

    }

  }

}
