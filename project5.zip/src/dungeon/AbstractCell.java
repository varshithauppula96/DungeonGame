package dungeon;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Abstract class to implement the interface cell in Dungeon. A cell can either be a cave or a
 * tunnel depending on the number of connectedCells it has. If the number of connectedCells are
 * 1,3,4 then it is a cave, else its a tunnel. The classes cave and tunnel are a subtype of cell.
 */
public abstract class AbstractCell implements Cell {
  private final int cellId;
  private final int rowId;
  private final int colId;
  private List<Sides> connectedSides;
  private String type;
  private List<Treasure> treasureAssigned;
  private Boolean treasuredFlag;
  private List<Otyughs> otyughsAssigned;
  private Boolean otyughsAssignedFlag;
  private int otyughsCount;
  private Boolean isArrowed;
  private int currentOtyughs;
  private boolean visitedFlag;


  /**
   * Constructor to initialise the rowid, colid and cell id of a given cell.
   *
   * @param row    rowId
   * @param col    colId
   * @param cellId cell id
   */
  public AbstractCell(int row, int col, int cellId) {
    if (row < 0) {
      throw new IllegalArgumentException("Enter a positive value for row");
    }
    if (col < 0) {
      throw new IllegalArgumentException("Enter a positive value for col");
    }
    if (cellId < 0) {
      throw new IllegalArgumentException("Enter a positive value for cellID");
    }
    this.connectedSides = new ArrayList<>();
    this.cellId = cellId;
    this.rowId = row;
    this.colId = col;
    this.type = "";
    treasuredFlag = false;
    treasureAssigned = new ArrayList<>();
    otyughsAssignedFlag = false;
    otyughsAssigned = new ArrayList<>();
    otyughsCount = 0;
    isArrowed = false;
    currentOtyughs = 0;
    this.visitedFlag = false;
  }

  @Override
  public void findConnectedCells(int width, int height, int[][] dung,
                                 List<ArrayList<Integer>> adjtemp, int wrap) {

    if (width < 0) {
      throw new IllegalArgumentException("Enter a positive value for width");
    }
    if (height < 0) {
      throw new IllegalArgumentException("Enter a positive value for height");
    }
    if (dung == null) {
      throw new IllegalArgumentException("Enter a non null dung matrix");
    }
    if (adjtemp == null) {
      throw new IllegalArgumentException("Enter a valid adjaceny list");
    }
    if (!(wrap == 1 || wrap == 2)) {
      throw new IllegalArgumentException("Enter a valid wrapping");
    }

    connectedSides = new ArrayList<>();
    int initial = -1;
    int rowN = initial;
    int rowW = initial;
    int rowE = initial;
    int rowS = initial;
    int colN = initial;
    int colW = initial;
    int colE = initial;
    int colS = initial;
    int elemN = initial;
    int elemS = initial;
    int elemE = initial;
    int elemW = initial;
    if (wrap == 2) {
      if (rowId - 1 >= 0) {
        rowN = rowId - 1;
        colN = colId;
        elemN = dung[rowN][colN];
      }
      if (colId - 1 >= 0) {
        rowW = rowId;
        colW = colId - 1;
        elemW = dung[rowW][colW];
      }
      if (colId + 1 < width) {
        rowE = rowId;
        colE = colId + 1;
        elemE = dung[rowE][colE];
      }
      if (rowId + 1 < height) {
        rowS = rowId + 1;
        colS = colId;
        elemS = dung[rowS][colS];
      }
    } else if (wrap == 1) {
      if (rowId - 1 >= 0) {
        rowN = rowId - 1;
        colN = colId;
        elemN = dung[rowN][colN];
      } else if (rowId - 1 < 0) {
        rowN = height - 1;
        colN = colId;
        elemN = dung[rowN][colN];
      }
      if (colId - 1 >= 0) {
        rowW = rowId;
        colW = colId - 1;
        elemW = dung[rowW][colW];
      } else if (colId - 1 < 0) {
        rowW = rowId;
        colW = width - 1;
        elemW = dung[rowW][colW];
      }
      if (colId + 1 < width) {
        rowE = rowId;
        colE = colId + 1;
        elemE = dung[rowE][colE];
      } else if (colId + 1 >= width) {
        rowE = rowId;
        colE = 0;
        elemE = dung[rowE][colE];
      }
      if (rowId + 1 < height) {
        rowS = rowId + 1;
        colS = colId;
        elemS = dung[rowS][colS];
      } else if (rowId + 1 >= height) {
        rowS = 0;
        colS = colId;
        elemS = dung[rowS][colS];
      }
    }
    int currElem = dung[rowId][colId];
    for (int j : adjtemp.get(currElem)) {
      if (j == elemN) {
        connectedSides.add(Sides.NORTH);
      }
      if (j == elemS) {
        connectedSides.add(Sides.SOUTH);
      }
      if (j == elemE) {
        connectedSides.add(Sides.EAST);
      }
      if (j == elemW) {
        connectedSides.add(Sides.WEST);
      }

    }


  }

  @Override
  public int getRow() {
    int copyRowId;
    copyRowId = rowId;
    return copyRowId;
  }

  @Override
  public int getCol() {
    int copyColId;
    copyColId = colId;
    return copyColId;
  }

  @Override
  public String getCellType() {
    findCellType();
    return new String(type);
  }

  @Override
  public void findCellType() {

    if (connectedSides.size() == 2) {
      type = "Tunnel";
    } else {
      type = "Cave";
    }
  }

  @Override
  public List<Sides> getConnectedSides() {

    List<Sides> copyConnectedSides = new ArrayList<>();
    for (Sides s : connectedSides) {
      copyConnectedSides.add(s);
    }
    return copyConnectedSides;
  }

  @Override
  public int getCellId() {
    int copyCellId;
    copyCellId = cellId;
    return copyCellId;
  }


  @Override
  public void assignTreasure() {
    findCellType();
    RandomInterface r = new RandomClassFixed(1, 1, 10);
    if (getCellType().equals("Cave")) {
      int randomNumber = (int) (Math.floor(Math.random() * (10 - 1 + 1) + 1));
      for (int k = 0; k < randomNumber; k++) {
        int pick = new Random().nextInt(Treasure.values().length);
        treasureAssigned.add(Treasure.values()[pick]);
      }

    }
    isTreasured();
  }

  @Override
  public void setIsArrowed(Boolean arrowValue) {
    if (arrowValue == null) {
      throw new IllegalArgumentException("Enter a valid value");
    }
    isArrowed = arrowValue;
  }

  @Override
  public Boolean getIsArrowed() {
    Boolean copyIsArrowed;
    copyIsArrowed = isArrowed;
    return copyIsArrowed;
  }

  @Override
  public void assignOtyughs(Otyughs otyughId) {
    if (otyughId == null) {
      throw new IllegalArgumentException("Enter a valid value");
    }
    findCellType();

    if (getCellType().equals("Cave")) {
      otyughsAssigned.add(otyughId);
      otyughsCount++;
    }


    isMonstered();
  }

  @Override
  public void isMonstered() {
    if (otyughsAssigned != null) {
      otyughsAssignedFlag = true;
    }
  }

  @Override
  public void isTreasured() {
    if (treasureAssigned != null) {
      treasuredFlag = true;
    }
  }

  @Override
  public int getOtyughsCount() {
    int otyughCountCopy;
    otyughCountCopy = otyughsCount;
    return otyughCountCopy;
  }

  @Override
  public boolean getIsTreasured() {
    boolean copyTreasuredFlag;
    copyTreasuredFlag = treasuredFlag;
    return copyTreasuredFlag;
  }


  @Override
  public void updateTreasure() {
    treasureAssigned = new ArrayList<>();
    treasuredFlag = false;
  }


  @Override
  public List<Treasure> getTreasure() {
    List<Treasure> copyTreasureAssigned;
    copyTreasureAssigned = treasureAssigned;
    return copyTreasureAssigned;
  }

  @Override
  public void updateOtyughsCount() {
    if (otyughsAssigned.get(currentOtyughs).getOtyughHealth() == 0) {
      otyughsCount--;
      otyughsAssigned.remove(currentOtyughs);
    }
  }

  @Override
  public void setHealth() {

    Otyughs currOty;
    currOty = otyughsAssigned.get(currentOtyughs);
    currOty.setOtyughsHealth();
    updateOtyughsCount();
  }

  @Override
  public List<Otyughs> getOtyughsAssigned() {
    List<Otyughs> copyOtyughList = new ArrayList<>();
    for (Otyughs o : otyughsAssigned) {
      copyOtyughList.add(o);
    }
    return copyOtyughList;
  }

  @Override
  public void setVisitedFlag() {
    visitedFlag = true;
  }

  @Override
  public boolean getVisitedFlag() {
    boolean copyVisitedFlag;
    copyVisitedFlag = visitedFlag;
    return copyVisitedFlag;
  }
}
