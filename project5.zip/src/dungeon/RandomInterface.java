package dungeon;

/**
 * Random Interface to implemennt the mock functionality of Random() java class to generate random
 * numbers deterministically.
 */
public interface RandomInterface {
  /**
   * Getter function to return the random number generated.
   *
   * @return randomNumber
   */
  public int getRandomNumber();
}
