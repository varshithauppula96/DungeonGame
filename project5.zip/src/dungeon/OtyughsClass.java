package dungeon;

/**
 * Class to implement the otyugh inerface which are smelly creatures that lead solitary lives in the
 * deep, dark places of the world like our dungeon.
 */
public class OtyughsClass implements Otyughs {

  private int locationId;
  private int otyughHealth;


  /**
   * Class to implement Otyughs smelly creatures that lead solitary lives in the deep, dark places
   * of the world like our dungeon.
   *
   * @param otyughsId  otyughs id
   * @param locationId location of otyughs
   */
  public OtyughsClass(int otyughsId, int locationId) {
    if (otyughsId < 0) {
      throw new IllegalArgumentException("Otyugh ID needs to be positive");
    }
    if (locationId < 0) {
      throw new IllegalArgumentException("Location id needs to be positive");
    }
    int otyughsID = otyughsId;
    this.locationId = locationId;
    otyughHealth = 100;
  }

  @Override
  public int getLocationId() {
    int copyLocation;
    copyLocation = locationId;
    return copyLocation;
  }

  @Override
  public void setOtyughHealth(int health) {
    if (health < 0) {
      throw new IllegalArgumentException("Enter a valid positive value");
    }
    otyughHealth = health;
  }

  @Override
  public int getOtyughHealth() {
    int copyHealth;
    copyHealth = otyughHealth;
    return copyHealth;
  }

  @Override
  public void setOtyughsHealth() {
    if (otyughHealth >= 50) {
      otyughHealth = otyughHealth - 50;
    }
  }


}
