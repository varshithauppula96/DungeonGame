package dungeon;

import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

/**
 * The interface for our view class.
 */
public interface IView {

  /**
   * Function to refresh the screen each time a key is pressed or an action occurs to load the
   * screen with new content.
   */
  public void refresh();

  /**
   * This class represents a keyboard listener. It is configurable by the controller that
   * instantiates it.
   *
   * <p>This listener keeps three maps, one each for key typed, key pressed and key
   * released Each map stores a key mapping. A key mapping is a pair (keystroke,code to be executed
   * with that keystroke) The latter part of that pair is actually a function object, i.e. an object
   * of a class that implements the Runnable interface
   *
   * <p>This class implements the KeyListener interface, so that its object can be
   * used as a valid key listener for Java Swing.
   */
  public void setListeners(ActionListener clicks, KeyListener keys);

  /**
   * Reset the focus on the appropriate part of the view that has the keyboard listener attached to
   * it, so that keyboard events will still flow through.
   */
  public void resetFocus();

}
