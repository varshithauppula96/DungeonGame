package dungeon;


/**
 * Class to implement the mocking functionality of Random(). This class returns the array of
 * elements in increasing order based on function calling it.
 */
public class RandomClassFixed implements RandomInterface {

  private int[] randomNumbers;
  private static int i;
  private static int called = 0;

  /**
   * Constructor to generate random numbers in a deterministic manner.
   *
   * @param called to decide how many times same function is calling the random.
   * @param min    min range
   * @param max    max range
   */
  public RandomClassFixed(int called, int min, int max) {
    if (called < 0) {
      throw new IllegalArgumentException("Please enter a positive value");
    }
    if (min < 0) {
      throw new IllegalArgumentException("Please enter a positive value");
    }
    if (max > 1000) {
      throw new IllegalArgumentException("Please enter a valid value");
    }
    randomNumbers = new int[max - min];
    int t = 0;
    for (int l = min; l < max; l++) {
      randomNumbers[t] = l;
      t++;
    }
    if (this.called == called) {
      i = 0;
    } else {
      if (i < t) {
        i++;
      } else {
        i = 0;
      }
    }
  }

  @Override
  public int getRandomNumber() {
    int copyRandomNumber;
    copyRandomNumber = randomNumbers[i];
    return copyRandomNumber;
  }


}
