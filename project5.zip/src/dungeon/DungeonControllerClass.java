package dungeon;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

/**
 * Controller of MVC model to interact with user to play the model to move the player through the
 * dungeon to reach the end.
 */
public class DungeonControllerClass implements DungeonController {
  private final Appendable output;
  private final Scanner scan;

  /**
   * Controller constructor to initisalise readable and scan to play the model.
   */
  public DungeonControllerClass(Readable in, Appendable out) {
    if (in == null || out == null) {
      throw new IllegalArgumentException("Readble input and appendable output cannot be null");
    }
    this.output = out;
    this.scan = new Scanner(in);
  }

  @Override
  public void playGame(DungeonModel model) {
    if (model == null) {
      throw new IllegalArgumentException("Enter a valid value");
    }
    Objects.requireNonNull(model);
    int start_node = -1;
    int end_node = -1;
    try {

      output.append("Welcome to the dungeon model !!! \n");


      output.append("creating dungeon.... \n");
      model.determineStartEnd();
      model.createPlayer();
      output.append("Enter number otyughs to be created.\n");
      int count = scan.nextInt();
      model.createOtyughs(count);
      output.append("Enter percentage of arrows and treasure to be created.\n");
      int percent = scan.nextInt();
      model.assignArrowsInCell(percent);
      model.assignTreasure(percent);


      output.append("dungeon created  !!! \n");
      output.append("Start Location is ");
      output.append(String.valueOf(model.getStart()) + "\n");
      output.append("End Location is ");
      output.append(String.valueOf(model.getEnd()) + "\n");
      start_node = model.getStart();
      end_node = model.getEnd();


      while (!model.isReachedDest() && model.isPlayerAlive()) {
        output.append("====================================" + "\n");
        output.append("          Current node info         " + "\n");
        output.append("====================================" + "\n");
        model.determineCellType();
        List<Integer> currLoc = new ArrayList<>();


        output.append("Player is at : " + model.getPlayer().determineCellType()
                + "\n");
        model.getPlayer().setPossibleMoves();
        output.append(model.getPlayer().getSidesList().toString());

        output.append(model.getPlayer().getPLayerLocationDesc()
                + "\n");
        model.determineSmell(model.getPlayer().getCurrentLocation());
        output.append(model.getSmell());
        output.append("====================================" + "\n");
        output.append("====================================" + "\n");
        output.append("select a action:" + "\n");
        output.append("Move, Pick or Shoot(M,P,S)?" + "\n");
        String action = scan.next();
        switch (action) {
          case "M":
            output.append("====================================" + "\n");
            output.append("           Move Action              " + "\n");
            output.append("====================================" + "\n");
            output.append("Pick a exit" + "\n");

            model.getPlayer().setPossibleMoves();
            output.append(model.getPlayer().printExits());
            String exit = scan.next();
            Sides side = null;
            if (exit.equals("N")) {
              side = Sides.NORTH;
            } else if (exit.equals("S")) {
              side = Sides.SOUTH;
            } else if (exit.equals("E")) {
              side = Sides.EAST;
            } else if (exit.equals("W")) {
              side = Sides.WEST;
            }
            model.getPlayer().movePlayer(side);
            break;
          case "P":
            output.append("====================================" + "\n");
            output.append("           Pick Action              " + "\n");
            output.append("====================================" + "\n");
            output.append("What to pick?(Treasure/Arrow)" + "\n");
            String item = scan.next();

            output.append(model.getPlayer().pick(item));
            output.append("You are still at the same place ").append("\n");
            break;

          case "S":
            output.append("====================================" + "\n");
            output.append("           Shoot Action             " + "\n");
            output.append("====================================" + "\n");
            output.append("Shoot arrow !!" + "\n");
            if (model.getPlayer().getPlayerArrowCount() == 0) {
              output.append("You ran out of arrows !! You cant shoot now" + "\n");
              break;
            }
            output.append("no of caves (1-5)" + "\n");
            int num_caves = scan.nextInt();
            if (num_caves > 5) {
              output.append("You can only shoot upto 5 caves" + "\n");
              break;
            }
            output.append("where to?" + "\n");
            String dir = scan.next();
            Sides direction = null;
            if (dir.equals("N")) {
              direction = Sides.NORTH;
            } else if (dir.equals("S")) {
              direction = Sides.SOUTH;
            } else if (dir.equals("E")) {
              direction = Sides.EAST;
            } else if (dir.equals("W")) {
              direction = Sides.WEST;
            }
            int num_of_arrows_left = 0;
            if (model.getPlayer().getPlayerArrowCount() > 0) {
              num_of_arrows_left = model.getPlayer().getPlayerArrowCount();
              output.append(model.getPlayer().slayOtyugh(direction, num_caves));
            }
            if (num_of_arrows_left == 0) {
              // display warning
              output.append("You are out of arrows, explore to find more"
                      + "\n");
            } else {
              output.append("You still have " + model.getPlayer().getPlayerArrowCount()
                      + "arrows left" + "\n");
            }

            break;

          default:
            output.append("Move, Pickup, or Shoot (M-P-S)? \n");
        }


      }
      model.determineWinner();
      if (model.getWinner() == 1) {
        output.append("Yay !!! you reached the end cave alive !!!" + "\n");
      } else if (model.getWinner() == 2) {
        output.append("====================================" + "\n");
        output.append("Chomp, chomp, chomp, you are eaten by an Otyugh!\n"
                +
                "Better luck next time     " + "\n");
        output.append("==============model OVER !!!!!==================" + "\n");
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("AppendFailed " + e.getStackTrace());
    }

  }
}

