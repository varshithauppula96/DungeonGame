package dungeon;

import java.util.Random;

/**
 * Class to implement the mocking functionality of Random(). This class returns the inbuilt
 * functionality of Random().
 */
public class RandomClass implements RandomInterface {
  int randomNumber;

  /**
   * Generate a random value in the range min to max.
   *
   * @param min min range
   * @param max max range
   */
  public RandomClass(int min, int max) {
    if (min < 0) {
      throw new IllegalArgumentException("Please enter a positive value");
    }
    if (max > 1000) {
      throw new IllegalArgumentException("Please enter a valid value");
    }
    Random random = new Random();
    int randomNumber = random.nextInt(max - min) + min;
  }

  @Override
  public int getRandomNumber() {
    int copyRandomNumber;
    copyRandomNumber = randomNumber;
    return copyRandomNumber;
  }

}
