import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import dungeon.Caves;
import dungeon.DungeonModel;
import dungeon.DungeonModelClass;
import dungeon.Player;
import dungeon.Sides;

import static junit.framework.TestCase.assertEquals;

/**
 * Test class to test the functionality of the functions in the dungeon class.
 */
public class DungeonModelTest {

  private DungeonModel dung1;
  private DungeonModel dung2;
  private DungeonModel dung3;


  @Before
  public void setup() {
    int width = 4;
    int height = 3;
    int wrapping = 2;
    int interconnectivity = 0;
    dung1 = new DungeonModelClass(width, height, wrapping, interconnectivity);
    dung2 = new DungeonModelClass(6, 4, 1, interconnectivity);
    dung3 = new DungeonModelClass(6, 4, 2, interconnectivity);

  }

  @Test
  public void testnonWrappingDung() {
    List<ArrayList<Integer>> testAdjList = new ArrayList<>();
    ArrayList<Integer> adjElems = new ArrayList<>();
    adjElems.add(1);
    adjElems.add(4);
    testAdjList.add(0, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(0);
    adjElems.add(2);
    adjElems.add(5);
    testAdjList.add(1, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(1);
    adjElems.add(3);
    adjElems.add(6);
    testAdjList.add(2, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(2);
    adjElems.add(7);
    testAdjList.add(3, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(0);
    adjElems.add(8);
    testAdjList.add(4, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(1);
    adjElems.add(9);
    testAdjList.add(5, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(2);
    adjElems.add(10);
    testAdjList.add(6, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(3);
    adjElems.add(11);
    testAdjList.add(7, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(4);
    testAdjList.add(8, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(5);
    testAdjList.add(9, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(6);
    testAdjList.add(10, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(7);
    testAdjList.add(11, adjElems);
    adjElems = new ArrayList<>();
    assertEquals(testAdjList, dung1.getAdjacencyList());
  }

  @Test
  public void testWrappingDung() {
    List<ArrayList<Integer>> testAdjList = new ArrayList<>();
    ArrayList<Integer> adjElems = new ArrayList<>();
    adjElems.add(18);
    adjElems.add(5);
    adjElems.add(1);
    adjElems.add(6);
    testAdjList.add(0, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(19);
    adjElems.add(0);
    adjElems.add(2);
    adjElems.add(7);
    testAdjList.add(1, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(20);
    adjElems.add(1);
    adjElems.add(3);
    adjElems.add(8);
    testAdjList.add(2, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(21);
    adjElems.add(2);
    adjElems.add(4);
    adjElems.add(9);
    testAdjList.add(3, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(22);
    adjElems.add(3);
    adjElems.add(10);
    testAdjList.add(4, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(23);
    adjElems.add(0);
    testAdjList.add(5, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(11);
    adjElems.add(0);
    adjElems.add(12);
    testAdjList.add(6, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(1);
    adjElems.add(13);
    testAdjList.add(7, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(2);
    adjElems.add(14);
    testAdjList.add(8, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(3);
    adjElems.add(15);
    testAdjList.add(9, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(4);
    adjElems.add(16);
    testAdjList.add(10, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(6);
    testAdjList.add(11, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(17);
    adjElems.add(6);
    testAdjList.add(12, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(7);
    testAdjList.add(13, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(8);
    testAdjList.add(14, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(9);
    testAdjList.add(15, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(10);
    testAdjList.add(16, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(12);
    testAdjList.add(17, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(0);
    testAdjList.add(18, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(1);
    testAdjList.add(19, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(2);
    testAdjList.add(20, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(3);
    testAdjList.add(21, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(4);
    testAdjList.add(22, adjElems);
    adjElems = new ArrayList<>();
    adjElems.add(5);
    testAdjList.add(23, adjElems);
    adjElems = new ArrayList<>();
    assertEquals(testAdjList, dung2.getAdjacencyList());
  }

  @Test
  public void testisConnected() {
    int[][] connectedMatrix = new int[3][4];
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 4; j++) {
        connectedMatrix[i][j] = 1;
      }
    }
    dung1.createConnectedMatrix();
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 4; j++) {
        assertEquals(connectedMatrix[i][j], dung1.getAdjMatrix()[i][j]);
      }
    }
  }

  @Test
  public void testDistance() {
    dung1.determineStartEnd();
    int start = dung1.getStart();
    int end = dung1.getEnd();
    List<ArrayList<Integer>> adjList = new ArrayList<>();
    adjList = dung1.getAdjacencyList();
    int distance = dung1.determineDistance(adjList, start, end, 12);
    String str = "";
    if (distance >= 5) {
      str = "yes";
    }
    assertEquals("yes", str);
  }

  @Test
  public void testTreasure() {

    int treasurePercent = 30;
    dung3.assignTreasure(treasurePercent);
    List<Caves> caveList = new ArrayList<>();
    caveList = dung3.getCaveList();
    int count = 0;
    for (Caves c : caveList) {
      if (c.getIsTreasured()) {
        count++;
      }
    }
    int size1 = caveList.size();
    int expected = (30 * size1 - 1) / 100;
    assertEquals(expected, count);
  }

  @Test
  public void testPLayerStartLoc() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    Player p = dung1.getPlayer();
    assertEquals(dung1.getStart(), p.getCurrentLocation());

  }

  @Test
  public void MovePLayer() {

    dung1.determineStartEnd();
    dung1.createPlayer();
    int start = dung1.getStart();
    int end = dung1.getEnd();
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.EAST);
    dung1.getPlayer().movePlayer(Sides.EAST);
    dung1.getPlayer().movePlayer(Sides.SOUTH);
    dung1.getPlayer().movePlayer(Sides.SOUTH);
    assertEquals(end, dung1.getPlayer().getCurrentLocation());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalWrapping() {
    DungeonModel dung5 = new DungeonModelClass(6, 4, 3, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalDimension() {
    DungeonModel dung5 = new DungeonModelClass(-1, -1, 1, 0);
  }


  @Test
  public void getPlayerDescription() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    StringBuilder str = new StringBuilder();
    str.append("Player id: 1");
    str.append("\n");
    str.append("Player Name: Player1");
    str.append("\n");
    str.append("TreasureCollected till now : {RUBIES=0, DIAMONDS=0, SAPPHIRES=0}");
    str.append("\n");
    assertEquals(str.toString(), dung1.getPlayer().getDescription().toString());
  }

  @Test
  public void testPLayersLocation() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    int treasurePercent = 100;
    dung1.assignTreasure(treasurePercent);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    StringBuilder str = new StringBuilder();
    str.append("Player currentLocation: 2");
    str.append("\n");
    str.append("Treasure in the Room []");
    str.append("\n");
    str.append("Possible moves from current locatino: [NORTH, SOUTH]");
    str.append("\n");

    assertEquals(str.toString(), dung1.getPlayer().getPLayerLocationDesc().toString());
  }

  @Test
  public void testOtyughInEndCave() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(4);
    Boolean flag = false;
    Map<Integer, List<Integer>> m1 = new HashMap<>();
    m1 = dung1.getIndexOfNodes();
    List<Integer> currLoc2 = new ArrayList<>();
    currLoc2 = m1.get(dung1.getEnd());
    int row1 = currLoc2.get(0);
    int col1 = currLoc2.get(1);
    dungeon.Cell[][] dungCellObject = new dungeon.Cell[3][4];
    dungCellObject = dung1.getDungeonCell();
    if (dungCellObject[row1][col1].getOtyughsCount() > 0) {
      flag = true;
    }
    assertEquals(Boolean.TRUE, flag);
  }

  @Test
  public void testSingleSmell() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(1);
    int start = dung1.getStart();
    int end = dung1.getEnd();
    String smell = "Less Pungent";
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.EAST);
    dung1.getPlayer().movePlayer(Sides.EAST);

    dung1.determineSmell(dung1.getPlayer().getCurrentLocation());
    String determinedSmell = dung1.getSmell();
    assertEquals(smell, determinedSmell);
  }

  @Test
  public void testMultipleSmell() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(18);
    int start = dung1.getStart();
    int end = dung1.getEnd();
    String smell = "More Pungent More Otyugh";
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.EAST);
    dung1.getPlayer().movePlayer(Sides.EAST);
    dung1.determineSmell(dung1.getPlayer().getCurrentLocation());
    assertEquals(smell, dung1.getSmell());
  }

  @Test
  public void testOtyughsAssigned() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(14);
    //run loop through matrix and increase count of otyughs
    dungeon.Cell[][] dungCellObject = new dungeon.Cell[3][4];
    dungCellObject = dung1.getDungeonCell();
    int count = 0;
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 4; j++) {
        count = count + dungCellObject[i][j].getOtyughsCount();
      }
    }
    assertEquals(14, count);
  }

  @Test
  public void testaddArrowDungeon() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(14);

    dungeon.Cell[][] dungCellObject = new dungeon.Cell[3][4];
    dungCellObject = dung1.getDungeonCell();
    dung1.assignArrowsInCell(80);
    boolean flag = false;
    outerloop:
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 4; j++) {
        flag = dungCellObject[i][j].getIsArrowed();
        if (flag) {
          break outerloop;
        }
      }
    }

    assertEquals(true, flag);
  }

  @Test
  public void testPickArrows() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(14);
    dungeon.Cell[][] dungCellObject = new dungeon.Cell[3][4];
    dungCellObject = dung1.getDungeonCell();
    dung1.assignArrowsInCell(70);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().addArrowList();
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().addArrowList();
    dung1.getPlayer().movePlayer(Sides.EAST);
    dung1.getPlayer().addArrowList();
    dung1.getPlayer().movePlayer(Sides.EAST);
    dung1.getPlayer().addArrowList();
    dung1.getPlayer().movePlayer(Sides.SOUTH);
    dung1.getPlayer().addArrowList();
    dung1.getPlayer().movePlayer(Sides.SOUTH);
    dung1.getPlayer().addArrowList();
    assertEquals(7, dung1.getPlayer().getPlayerArrowCount());

  }

  @Test
  public void testShootArrow() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(14);
    dung1.createPlayer();
    dung1.assignArrowsInCell(80);
    dung1.getPlayer().slayOtyugh(Sides.NORTH, 1);
    assertEquals(10, dung1.getStart());
    assertEquals(2, dung1.getPlayer().getArrowCurrenLoc());
  }

  @Test
  public void testShootArrowOtyugh() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(7);
    dung1.createPlayer();
    dung1.assignArrowsInCell(80);


    // GET Count of otyughs, shoot once, shoot twice get count again.

    dungeon.Cell[][] dungCellObject = new dungeon.Cell[3][4];
    dungCellObject = dung1.getDungeonCell();
    int count = dungCellObject[0][2].getOtyughsCount();
    assertEquals(1, count);
    dung1.getPlayer().slayOtyugh(Sides.NORTH, 1);
    count = dungCellObject[0][2].getOtyughsCount();
    assertEquals(1, count);
    dung1.getPlayer().slayOtyugh(Sides.NORTH, 1);
    count = dungCellObject[0][2].getOtyughsCount();
    assertEquals(0, count);

    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.determineWinner();
    assertEquals(0, dung1.getWinner());
    dung1.getPlayer().movePlayer(Sides.EAST);
    dung1.getPlayer().movePlayer(Sides.SOUTH);
    dung1.getPlayer().movePlayer(Sides.SOUTH);

    dung1.determineWinner();
    assertEquals(1, dung1.getWinner());
  }

  @Test
  public void testOtyughMiss() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(26);
    dung1.assignArrowsInCell(10);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.WEST);

    // GET Count of otyughs, shoot once, shoot twice get count again.

    dungeon.Cell[][] dungCellObject = new dungeon.Cell[3][4];
    dungCellObject = dung1.getDungeonCell();
    int count = dungCellObject[0][1].getOtyughsCount();
    assertEquals(5, count);
    dung1.getPlayer().slayOtyugh(Sides.EAST, 1);
    //assertEquals(5,count);
    dung1.getPlayer().slayOtyugh(Sides.EAST, 1);
    assertEquals(5, count);
  }

  @Test
  public void testKillPlayer() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(26);
    dung1.assignArrowsInCell(80);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.determineWinner();
    assertEquals(2, dung1.getWinner());
  }

  @Test
  public void testFiftyChance() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(4);
    dung1.createPlayer();
    dung1.assignArrowsInCell(80);
    int playerWinner = 0;
    int otyughWinner = 0;
    boolean flag = false;
    for (int i = 0; i < 8; i++) {
      dung1.getPlayer().slayOtyugh(Sides.NORTH, 1);
      dung1.getPlayer().movePlayer(Sides.NORTH);
      dung1.getPlayer().movePlayer(Sides.NORTH);


      dung1.determineWinner();
      if (dung1.getWinner() == 0) {
        playerWinner++;
      } else if (dung1.getWinner() == 2) {
        otyughWinner++;
      }
      if (otyughWinner > 0 && playerWinner > 0) {
        flag = true;
      }

    }
    assertEquals(true, flag);
  }

  @Test
  public void testOtyughDies() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    dung1.createOtyughs(26);
    dung1.createPlayer();
    dung1.assignArrowsInCell(10);


    // GET Count of otyughs, shoot once, shoot twice get count again.

    dungeon.Cell[][] dungCellObject = new dungeon.Cell[3][4];
    dungCellObject = dung1.getDungeonCell();
    int count = dungCellObject[0][2].getOtyughsCount();
    assertEquals(5, count);
    dung1.getPlayer().slayOtyugh(Sides.NORTH, 1);
    count = dungCellObject[0][2].getOtyughsCount();
    assertEquals(5, count);
    dung1.getPlayer().slayOtyugh(Sides.NORTH, 1);
    count = dungCellObject[0][2].getOtyughsCount();
    assertEquals(4, count);

    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.determineWinner();
    assertEquals(2, dung1.getWinner());
  }

  @Test
  public void testTreasureCollected() {
    dung1.determineStartEnd();
    dung1.createPlayer();
    int treasurePercent = 50;
    dung1.assignTreasure(treasurePercent);
    StringBuilder str = new StringBuilder();
    str.append("{RUBIES=0, DIAMONDS=0, SAPPHIRES=0}");
    Map<Integer, List<Integer>> index;
    index = dung1.getIndexOfNodes();
    int start = dung1.getStart();
    int end = dung1.getEnd();
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().addTreasureCollected();
    dung1.getPlayer().movePlayer(Sides.NORTH);
    dung1.getPlayer().addTreasureCollected();
    dung1.getPlayer().movePlayer(Sides.EAST);
    dung1.getPlayer().addTreasureCollected();
    dung1.getPlayer().movePlayer(Sides.EAST);

    dung1.getPlayer().movePlayer(Sides.SOUTH);

    dung1.getPlayer().movePlayer(Sides.SOUTH);

    assertEquals(str.toString(), dung1.getPlayer().getTreasureCollected().toString());
  }


}

