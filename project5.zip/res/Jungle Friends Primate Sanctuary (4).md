#  Dungeons

The world for our game consists of a dungeon, a network of tunnels and caves that are interconnected so that player can explore the entire world by traveling from cave to cave through the tunnels that connect them. Dungeon also contains monsters that can can be slayed by the player. This provides a way for the player to both win and lose the game.
A GUI is built to view the Dungeon model and play the game.
_

- Varshitha Uppula
- Project5 - PDP

## Features

- Dungeon is represented by a two-dimensional grid based on user input,
 -Dungeon has player in it.
-dungeon locations can "wrap" to the one on the other side of the grid.
-A location can further be classified as tunnel (which has exactly 2 entrances) or a cave (which has 1, 3 or 4 entrances). 
-player can explore and can be connected to at most four (4) other locations: one to the north, one to the east, one to the south, and one to the west.
-There should be a path from every cave in the dungeon to every other cave in the dungeon.
-Each dungeon can be constructed with a degree of interconnectivity. We define an interconnectivity = 0 when there is exactly one path from every cave in the dungeon to every other cave in the dungeon. Increasing the degree of interconnectivity increases the number of paths between caves.
-One cave is randomly selected as the start and one cave is randomly selected to be the end. The path between the start and the end locations should be at least of length 5.
-support for at least three types of treasure: diamonds, rubies, and sapphires
-treasure to be added to a specified percentage of caves. A cave can have more than one treasure.
-a player to pick up treasure that is located in their same location
-Otyughs (Links to an external site.) are extremely smelly creatures that lead solitary lives in the deep, dark places of the world like our dungeon.
-here is always at least one Otyugh in the dungeon located at the specially designated end cave. The actual number is specified on the command line. There is never an Otyugh at the start.
-They can be detected by their smell. In general, the player can detect two levels of smell:
a less pungent smell can be detected when there is a single Otyugh 2 positions from the player's current location
detecting a more pungent smell either means that there is a single Otyugh 1 position from the player's current location or that there are multiple Otyughs within 2 positions from the player's current location
-Player starts with 3 crooked arrows but can find additional arrows in the dungeon with the same frequency as treasure. Arrows can be found in both caves and tunnels.
-A player that has arrows, can attempt to slay an Otyugh by specifying a direction and distance in which to shoot their crooked arrow. Distance is defined as the number of caves (but not tunnels) that an arrow travels.
-It takes 2 hits to kill an Otyugh. Players has a 50% chance of escaping if the Otyugh if they enter a cave of an injured Otyugh that has been hit by a single crooked arrow.
GUI Interface has following functionalities:
-GUI exposes all game settings including the size of the dungeon, the interconnectivity, whether it is wrapping or not, the percentage of caves that have treasure, and the number of Otyughs through one or more items
-option for quitting the game, restarting the game as a new game with a new dungeon or reusing the same dungeon through one or more items on a JMenu.
-display the dungeon to the screen using graphical representation. The view should begin with a mostly blank screen and display only the pieces of the maze that have been revealed by the user's exploration of the caves and tunnels. Dungeons that are bigger than the area allocated it to the screen should provide the ability to scroll the view.
-allow the player to move through the dungeon using a mouse click on the screen in addition to the keyboard arrow keys. A click on an invalid space in the game would not advance the player.
-display the details of a dungeon location to the screen. For instance, does it have treasure, does it have an arrow, does it smell.
-provide an option to get the player's description
-provide an option for the player to pick up a treasure or an arrow through pressing a key on the keyboard.
-provide an option for the player to shoot an arrow by pressing a key on the keyboard followed by an arrow key to indicate the direction.
-provide a clear indication of the results of each action a player takes.

## How to Run

1. Add Java to Windows -https://windowsreport.com/outdated-java-windows-10/
You'll find below a path to the latest Java version in case you need it.
Then, you can find JAR file openers or executors, and we recommend some. 
Using Command Prompt is also a handy solution if you don't want to install third-party tools.
2. Download a JAR file opener
3. Open the File Explorer and the folder that includes the file you need to run.
4. You should right-click the JAR file and select Open with from the context menu.
5. Click Choose another app and then select to open it with Java(TM) Platform SE binary.
 

0r-

1. Press the Win key + X hotkey and select Command Prompt (Admin) to open it as administrator.
2. Then input the following command (replacing the example with the actual path of the file you need to run) and press Enter:
java -jar c:pathtojarfile.jar


## How to use the program

-Run the Jar file: java -jar project5.jar


## Description of Examples to show functionality of Project

1) run1 

Create a dungeon with no wrapping and interconnectivity of 0, that means there exists only one path from each node in a cell to another. Shows the movement of the player through the dungeon, collecting treasure and arrows on the way 
[WEST, EAST, SOUTH]Player currentLocation: 2


*************************************************************
run 2:
Create a dungeon with no wrapping and interconnectivity of 0, that means there exists only one path from each node in a cell to another. Shows the movement of the player through the dungeon and the player being eaten by a Otyugh.


**************************************************************

Run3: Determine if pungent cause of more than 1 otyugh in distance of 2 or 1 otyugh in distanc of 1.


## Design and Model changes

Added a function to check if a particular cell is visited. This feature allows the dungeon to be black until a particular cell has been visited by the player.


#### Assumptions
- interconnectivity cannot be more than possible unconnected edges.
- treasure needs to be a percent within 0 to 100.
- Arrow percentage and treasure percentage is the same.
- When arrow is shot, tunnels are not considered.
- Dungeon has min size 5x5


## Limitation
- Only one player can move in a dungeon at a time
- Treasure once collected cannot be removed
- PLayer doesn't know path to take in advance
- only three types of treasure supported as of now
- Not necessary that the number of arrows are more than needed to kill the otyugh.
- individual treasure and arrows cannot be picked, everything in the cell needs to be picked.


## Citation

https://www.geeksforgeeks.org/kruskals-minimum-spanning-tree-algorithm-greedy-algo-2/

https://algorithms.tutorialhorizon.com/kruskals-algorithm-minimum-spanning-tree-mst-complete-java-implementation/

https://www.youtube.com/results?search_query=overlay+2+images+in+java+swing

https://github.com/HexagonNico/Dungeon-Crawler

Maria JUmp code for MVCExample

https://docs.oracle.com/en/java/javase/11/docs/api/java.desktop/javax/swing/JMenu.html




